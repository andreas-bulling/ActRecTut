#include <BoostingData.h>
#include <featurevector.hh>


Data::Data(size_t D, size_t C) : m_samples_of_class(C + 1), classWeights(C, 1.0), background(C, false) {
	m_D = D;
	m_C = C;
	m_N = 0;
}

void Data::clear() {
	m_samples.clear();

	for(size_t i = 0; i < m_samples_of_class.size(); ++i)
		m_samples_of_class[i].clear();

	classWeights = std::vector<float>(m_C, 1.0);
	m_N = 0;

	resetBackgroundClasses();
}

Data::~Data() {
	clear();
}

void Data::addSample(FeatureVector* s) {
	assert(s->numDims() == static_cast<int>(m_D));
	m_samples.push_back(s);

	if (s->getTargetClass() == -1)
		m_samples_of_class[m_C].push_back(s);
	else {
		assert(s->getTargetClass() < static_cast<int>(m_C));
		m_samples_of_class[s->getTargetClass()].push_back(s);
	}
	m_N++;
}

void Data::addSampleVector(std::vector<FeatureVector> &s) {
	for(size_t i = 0; i < s.size(); i++) {
		addSample(&s[i]);
	}
}
