#include <AdaBoost.h>
#include <iostream>
#include <fstream>
#include <math.h>
#include <iomanip>
#include <algorithm>
#include <cmath>

using namespace std;

void AdaBoostClassifier::trainClassifier(Data* TrainingData, const BoostingParam& boost_param, std::ostream *outStream) {
	m_v = TrainingData;
	const vector<FeatureVector*>* samples = m_v->getAllSamples();

	if (m_v->getC() != 2) {
		if (outStream)
			(*outStream)  << "ERROR: Discrete AdaBoost only supports two class classification problems!" << endl;
	}

	if (boost_param.IndexedTraining)
		prepareIndex(outStream);

	if (outStream) {
		(*outStream) << "===========================================================" << endl;
		(*outStream) << "Starting to learn an ensemble classifier..." << endl;
		(*outStream) << "Boosting rounds: " << boost_param.numRounds << endl;
		(*outStream) << "Number of classes: " << m_v->getC() << endl;
		(*outStream) << "Data dimensionality: " << m_v->getD() << endl;
		for (size_t i = 0; i < m_v->getC(); i++)
			(*outStream) << "# Training instances for class " << i << ": " << m_v->getSamplesOfClass(i)->size() << endl;
		(*outStream) << "===========================================================" << endl;
	}

	srand(boost_param.randomSeed);

	//Initialize weights
	weights.clear();
	weights.resize(m_v->getN());

	size_t m = m_v->getSamplesOfClass(0)->size();
	size_t l = m_v->getSamplesOfClass(1)->size();

	for(size_t i = 0; i < m_v->getN(); i++) {
		if ( (*samples)[i]->getTargetClass() == 0)
			weights[i] = 1.0f * m_v->getClassWeight(0) * (*samples)[i]->getInstanceWeight() / 2.0f / m;
		else
			weights[i] = 1.0f * m_v->getClassWeight(1) * (*samples)[i]->getInstanceWeight() / 2.0f / l;
	}

	//Initialize ensemble
	stumps.clear();

	//Assert we are in [0,1]
	subSampleRate = std::min(1.0f, std::fabs(boost_param.subSampleRate));
	numberSamples = static_cast<size_t>(ceilf(m_v->getD() * boost_param.subSampleRate ));

	//A list of all dimensions to draw from
	fullPool = std::vector<size_t>(m_v->getD());
	sampledPool = std::vector<size_t>(numberSamples);
	for(size_t i = 0; i < m_v->getD(); ++i)
		fullPool[i] = i;

	performRounds(boost_param.numRounds, boost_param, 0, outStream);

	computeSigmoidParams(m_v, outStream);
}

float AdaBoostClassifier::computeError(Data* ValidationData, std::ostream* outStream) {
	const std::vector<FeatureVector*>* allSamples(ValidationData->getAllSamples());

	float error = 0;
	for(size_t i = 0; i < allSamples->size(); ++i) {

		float margin = evaluateFeaturePoint( (*(*allSamples)[i] ), Ratio );

		if (margin >= 0.5 && (*allSamples)[i]->getTargetClass() == 0 )
			error+= ValidationData->getClassWeight(0) * (*allSamples)[i]->getInstanceWeight();

		if (margin < 0.5 && (*allSamples)[i]->getTargetClass() == 1 )
			error+= ValidationData->getClassWeight(1) * (*allSamples)[i]->getInstanceWeight();
	}

	if (outStream)
		(*outStream) << "Classification error: " << error << std::endl;

	return error;
}

void AdaBoostClassifier::performRounds(unsigned int numRounds, const BoostingParam& boost_param, Data* TrainingData, std::ostream *outStream, size_t roundOffset) {
	if(TrainingData)
		m_v = TrainingData;

	if (!m_v || weights.size() == 0) {
		cout << "No training data available or invalid weights!" << endl;
		return;
	}

	for(unsigned int m = 0; m < numRounds; m++) {
		if (outStream) {
			(*outStream) << "Performing boosting round number: " << m + roundOffset;
			 std::flush(*outStream);
		}

		//Normalize the weights
		float sum = 0;
		for(unsigned int i = 0; i < weights.size(); i++) {
			sum += weights[i];
		}
		for(unsigned int i = 0; i < weights.size(); i++) {
			weights[i] /= sum;
			//cout << "weight " << i << " : " << weights[i] << " value: " <<  (*m_v->getAllSamples())[i]->getData(1) << endl;
		}

		//Sample dimensions if subSampleRate != 1.0
		std::vector<size_t>* chosenFeatures;
		if(subSampleRate != 1.0) {
			size_t maxF = m_v->getD() - 1;

			for(size_t i = 0; i < numberSamples; ++i, --maxF) {
				size_t index = static_cast<size_t>(roundf(maxF * (rand() *  1.0f / RAND_MAX)));
				sampledPool[i] = fullPool[index];
				std::swap(fullPool[index], fullPool[maxF]);
			}

			chosenFeatures = &sampledPool;

		} else {
			chosenFeatures = &fullPool;
		}

		DecisionStump addedStump;
		for(size_t d = 0; d < chosenFeatures->size(); d++) {
			DecisionStump bestStumpForDimension = boost_param.IndexedTraining ? getBestWeakLearnerWithIndex( (*chosenFeatures)[d]) : getBestWeakLearnerWithoutIndex((*chosenFeatures)[d]);

			//cout << "d: " << d << " " << bestStumpForDimension.J_wse << endl;

			//If we do better than with previous stumps keep stump for dimension d
			if (bestStumpForDimension.J_wse < addedStump.J_wse || d == 0) {
				addedStump = bestStumpForDimension;
			}
		}


		//update weights[i]
		const vector<FeatureVector*>* samples = m_v->getAllSamples();

		float beta_t = addedStump.J_wse / (1 - addedStump.J_wse);

		for(size_t i = 0; i < m_v->getN(); i++) {

			const float h = (*samples)[i]->getData(addedStump.f) * addedStump.p < addedStump.theta * addedStump.p ? 1 : 0;
			const float e_i = (*samples)[i]->getTargetClass() == h ? 0 : 1;

			if (updateMode == 0)
				if (e_i == 0)
					weights[i] = weights[i] * beta_t;

			if(updateMode == 1)
				weights[i] = weights[i] * std::exp(addedStump.alpha * e_i);

		}

		if (outStream) {
			(*outStream) << " alpha: " << addedStump.alpha << ", p: " << addedStump.p << ", dim: " << addedStump.f <<  ", Error: " << addedStump.J_wse << ", Theta: " << addedStump.theta << std::endl;
		}

		//if all training samples are classified correctly we can stop
		if (addedStump.J_wse == 0) {
			stumps.push_back(addedStump);
			break;
		} else {
			//add the stump
			stumps.push_back(addedStump);
		}

	}

	sum_alpha = 0;
	for(unsigned int i = 0; i < stumps.size(); i++)
		sum_alpha += stumps[i].alpha;
}

DecisionStump AdaBoostClassifier::getBestWeakLearnerWithIndex(size_t d) {
	DecisionStump r;
	r.J_wse = 1;

	const vector<FeatureVector*>* samples = m_v->getAllSamples();

	float S_p = 0;
	float S_m = 0;
	float T_p = 0;
	float T_m = 0;

	//Get overall positive and negative weight
	for(size_t i = 0; i < m_v->getN(); i++) {
		if ((*samples)[i]->getTargetClass() == 1)
			T_p += weights[i];
		else
			T_m += weights[i];
	}

	float rememberLower = (*samples)[sorted_index[d][0]]->getData(d);
	for(size_t i = 0; i < m_v->getN(); i++) {

		size_t& sorted_ind = sorted_index[d][i];
		size_t& sorted_ind1 = sorted_index[d][i - 1];

		//Cumulate weights lower than thresholds
		if(i > 0) {
			if ((*samples)[sorted_ind1]->getTargetClass() == 1)
				S_p += weights[sorted_ind1];
			else
				S_m += weights[sorted_ind1];


			if ((*samples)[sorted_ind]->getData(d) == (*samples)[sorted_ind1]->getData(d))
				continue;
			else
				rememberLower = (*samples)[sorted_ind1]->getData(d);
		}

		// " < " case
		if (i == 0 || S_m + T_p - S_p < r.J_wse) {
			r.f = d;
			r.p = 1;
			r.theta = ((*samples)[sorted_ind]->getData(d) + rememberLower) / 2;
			r.J_wse =  S_m + T_p - S_p;
			r.value = 0;
			r.alpha = logf((1 - r.J_wse)/ (r.J_wse + 1e-8));
		}

		// " > " case
		if (S_p + T_m - S_m < r.J_wse) {
			r.f = d;
			r.p = -1;
			r.theta = ((*samples)[sorted_ind]->getData(d) + rememberLower) / 2;
			r.J_wse = S_p + T_m - S_m;
			r.value = 0;
			r.alpha = logf((1 - r.J_wse)/ (r.J_wse + 1e-8));
		}
	}
	return r;
}

DecisionStump AdaBoostClassifier::getBestWeakLearnerWithoutIndex(size_t d) {
	DecisionStump r;
	r.J_wse = 1;

	const vector<FeatureVector*>* samples = m_v->getAllSamples();

	vector<BoostingDataPoint> data;
	data.reserve(m_v->getN());
	for(size_t i = 0; i < m_v->getN(); i++) {
		data.push_back(BoostingDataPoint ( (*samples)[i]->getData(d), i ) );
	}
	std::sort(data.begin(), data.end());

	float S_p = 0;
	float S_m = 0;
	float T_p = 0;
	float T_m = 0;

	//Get overall positive and negative weight
	for(unsigned int i = 0; i < data.size(); i++) {
		//cout << (*samples)[data[i].id]->getData(d) << " " << data[i].id << " " << (*samples)[data[i].id]->getTargetClass() << " weight:" << weights[i] << endl;
		if ((*samples)[data[i].m_index]->getTargetClass() == 1)
			T_p += weights[data[i].m_index];
		else
			T_m += weights[data[i].m_index];
	}

	float rememberLower = data[0].m_value;
	for(unsigned int i = 0; i < data.size(); i++) {

		//Cumulate weights lower than thresholds
		if(i > 0) {
			if ((*samples)[data[i-1].m_index]->getTargetClass() == 1)
				S_p += weights[data[i-1].m_index];
			else
				S_m += weights[data[i-1].m_index];


			if (data[i].m_value == data[i-1].m_value)
				continue;
			else
				rememberLower = data[i-1].m_value;
		}

		// " < " case
		if (i == 0 || S_m + T_p - S_p < r.J_wse) {
			r.f = d;
			r.p = 1;
			r.theta = (data[i].m_value + rememberLower) / 2;
			r.J_wse =  S_m + T_p - S_p;
			r.value = 0;
			r.alpha = logf((1 - r.J_wse)/ (r.J_wse + 1e-8));
		}

			// " > " case
		if (S_p + T_m - S_m < r.J_wse) {
			r.f = d;
			r.p = -1;
			r.theta = (data[i].m_value + rememberLower) / 2;
			r.J_wse = S_p + T_m - S_m;
			r.value = 0;
			r.alpha = logf((1 - r.J_wse)/ (r.J_wse + 1e-8));
		}
	}

	return r;
}

AdaBoostClassifier::AdaBoostClassifier() : m_v(0), updateMode(0) {
}

float AdaBoostClassifier::evaluateFeaturePoint(const FeatureVector &v, Boosting_Normalization normalize, unsigned int rounds) {
	unsigned int activeStumps = stumps.size();
	if(rounds != 0) {
		activeStumps = rounds;
	}

	// Evaluate all features
	register float s = 0;
	for(unsigned int i = 0; i < activeStumps; i++) {
		const float &val = v.getData(stumps[i].f);
		stumps[i].value = (val * stumps[i].p  < stumps[i].theta * stumps[i].p) ? stumps[i].alpha : 0;
		s += stumps[i].value;
	}

	switch(normalize) {
		case Ratio: {
			s /= sum_alpha;
			break;
		}

		case Sigmoid: {
			register float fApB = s * A + B;
			if (fApB >= 0)
				s = std::exp(-fApB)/(1.0f + std::exp(-fApB));
			else
				s = 1.0f /(1.0f + std::exp(fApB));
			break;
		}

		default:
			break;
	}

	return s;
}

void AdaBoostClassifier::printEnsemble() {
	for(unsigned int c = 0; c < stumps.size(); c++) {
		cout << "Feature number: " << stumps[c].f << endl;
		cout << "Theta: " << stumps[c].theta << endl;
		cout << "p: " << stumps[c].p << endl;
		cout << "alpha: " << stumps[c].alpha << endl;
		cout << "J_wse: " << stumps[c].J_wse << endl;
		cout << "---------------------------------------------" << endl;
	}
	cout << "================================================================" << endl;
}

vector<DecisionStump> AdaBoostClassifier::getAllStumps() {
	return stumps;
}

ostream& operator<<(ostream& output, AdaBoostClassifier& jb) {
	try {
		output << setprecision(15) << jb.stumps.size() << "\t" << endl;

		for(unsigned int i = 0; i < jb.stumps.size(); i++) {
			output << jb.stumps[i].f << "\t" << jb.stumps[i].p << "\t" << jb.stumps[i].alpha << "\t" << jb.stumps[i].J_wse << "\t" << jb.stumps[i].theta << "\t" << endl;
		}

		output << jb.A << "\t" << jb.B << endl;

	} catch(iostream::failure) {
		cerr << "Could not write to stream...";
		throw;
	}
	return output;
}

istream& operator>>(istream& input, AdaBoostClassifier& jb) {
	//Reset Data to make sure training data and classifier match
	jb.m_v = 0;
	jb.stumps.clear();

	try {
		//Restore number of rounds, i.e. number of stumps
		unsigned int ns;
		input >> ns;
		jb.stumps.resize(ns);

		jb.sum_alpha = 0;
		//Restore stumps
		for(unsigned int i = 0; i < ns; i++) {
			DecisionStump r;
			input >> r.f >> r.p >> r.alpha >> r.J_wse >> r.theta;
			jb.stumps[i] = r;
			jb.sum_alpha += r.alpha;
		}

		input >> jb.A;
		input >> jb.B;

	} catch(iostream::failure) {
		cerr << "Could not read from stream..." << endl;
		throw;
	}
	return input;
}

void AdaBoostClassifier::loadClassifier(std::string filename) {
	ifstream f(filename.c_str());
	f >> (*this);
}

void AdaBoostClassifier::saveClassifier(std::string filename) {
	if (!stumps.size()) return;

	ofstream f(filename.c_str());
	f << (*this);
}

void AdaBoostClassifier::computeSigmoidParams(const Data* trainData, std::ostream *outStream) {

	if(outStream)
		(*outStream) << "Computing sigmoid paramters..." << std::endl;

	const std::vector<FeatureVector*>* allSamples = trainData->getAllSamples();

	std::vector<double> scores (trainData->getN());

	for(size_t i = 0; i < allSamples->size() ; ++i) {
		 scores[i] = evaluateFeaturePoint( *(*allSamples)[i], None, false);
	}

	std::vector<double> label(trainData->getN());

	for(size_t i = 0; i < allSamples->size() ; ++i) {
		if( (*allSamples)[i]->getTargetClass() == 1 ) {
			label[i] = 1;
		} else {
			label[i] = -1;
		}
	}

	sigmoid_train(scores, label, A, B);

	if(outStream)
		(*outStream) << " A: " << A << " B: " << B << std::endl;
}

void AdaBoostClassifier::prepareIndex(std::ostream* outStream) {
	const vector<FeatureVector*>* samples = m_v->getAllSamples();

	if (outStream) {
		(*outStream) << "===========================================================" << endl;
		(*outStream) << "Preparing index..." << endl;
	}

	std::vector<BoostingDataPoint> sorted;

	//Clear the sorted index and thetas
	sorted_index.clear();
	sorted_index.resize(m_v->getD());

	for(size_t j = 0; j < m_v->getD(); j++) {
		if (outStream)
				(*outStream) << "Sorting dimension " << j << "..." << endl;

		sorted.clear();
		for(size_t i = 0; i < m_v->getN(); i++)
			sorted.push_back( BoostingDataPoint((*samples)[i]->getData(j), i) );

		std::sort(sorted.begin(), sorted.end());

		for(size_t i = 0; i < m_v->getN(); ++i)
			sorted_index[j].push_back(sorted[i].m_index);

		if (outStream)
			(*outStream) << "\tMin: " << (*samples)[sorted.front().m_index]->getData(j) << " Max: " << (*samples)[sorted.back().m_index]->getData(j) << std::endl;

	}

	if (outStream)
			(*outStream) << "===========================================================" << endl;
}
