%MEXJOINTBOOSTING wrapper for the fast c++ JointBoosting library
%
%1) training
%[setidx,param,kc] = mexjointboosting(numberOfClasses, classIdx, features, numWeakClassifiers, 0);
%
%where:
%numberOfClasses is int > 0
%classIdx is nx1 vector of int > 0. n is the number of training samples
%features is nxd matrix. n is number of training samples of dimension d
%numWeakClassifiers is int > 0 
%
%fifth parameter is omitted for now
%
%2) classification
%class = mexjointboosting(vec) 
%
%where:
%vec is dx1 datavector
%class is nx1 class prediction vector
%
%3) resetting
%calling mexjointboosting without parameters resets the classifier
%