#include <jointBoosting.h>
#include <iostream>
#include <fstream>
#include <math.h>
#include <iomanip>
#include <algorithm>
#include <set>
#include <cmath>

using namespace std;

size_t binary_find(const std::vector<BoostingDataPoint>& sorted_data, size_t lowerID, size_t upperID, double value) {
       if (lowerID == upperID)
               return lowerID;

       if( value <= sorted_data[(lowerID + upperID) / 2].m_value )
               return binary_find(sorted_data, lowerID, (lowerID + upperID) / 2, value);
       else
               return binary_find(sorted_data, (lowerID + upperID) / 2 + 1, upperID, value);
}

void JointBoostClassifier::prepareIndex(std::ostream *outStream, bool IndexedTraining, JB_Scanning scanMethod, size_t numTheta) {
	/*
	 * Set up possible values for theta by scanning for mins and maxs
	 * in each dimension and then take equal steps from min to max
	 */

	const vector<FeatureVector*>* samples = m_v->getAllSamples();
	FeatureVector mins(m_v->getD());
	FeatureVector maxs(m_v->getD());

	if (outStream) {
		(*outStream) << "===========================================================" << endl;
		(*outStream) << "Computing thetas/ preparing index..." << endl;
	}

	//Clear the sorted index and thetas
	sorted_index.clear();
	if(IndexedTraining) {
		sorted_index.resize(m_v->getD());
	}

	theta.clear();
	theta_index.clear();
	if(scanMethod == Quantiles || scanMethod == Linear) {
		theta.resize(m_v->getD());
		theta_index.resize(m_v->getD());
	}

	theta_class.clear();
	theta_class_index.clear();
	if(scanMethod == Boundaries) {
		theta_class.resize(m_v->getC());
		for(size_t i = 0; i < m_v->getC(); ++i)
			theta_class[i].resize(m_v->getD());

		theta_class_index.resize(m_v->getC());
		for(size_t i = 0; i < m_v->getC(); ++i)
			theta_class_index[i].resize(m_v->getD());
	}

	for(size_t j = 0; j < m_v->getD(); j++) {
		if (outStream)
				(*outStream) << "Sorting dimension " << j << "..." << endl;

		sorted_data.clear();
		sorted_data.reserve(m_v->getN());
		for(size_t i = 0; i < m_v->getN(); i++)
			sorted_data.push_back( BoostingDataPoint((*samples)[i]->getData(j), i) );

		std::sort(sorted_data.begin(), sorted_data.end());

		if(outStream)
			(*outStream) << "\tMin: " << (*samples)[sorted_data.front().m_index]->getData(j) << " Max: " << (*samples)[sorted_data.back().m_index]->getData(j) << endl;

		if(IndexedTraining) {
			for(size_t i = 0; i < m_v->getN(); ++i)
				sorted_index[j].push_back(sorted_data[i].m_index);
		}

		if(scanMethod == Quantiles) {
			float binStep = sorted_data.size() * 1.0f / (numTheta + 2);

			for(unsigned int i = 0; i < numTheta; i++) {
				size_t index = static_cast<int>(round((i + 1) * binStep));
				while(index < m_v->getN() - 1 && sorted_data[index].m_value == sorted_data[index + 1].m_value)
					++index;

				theta[j].push_back(sorted_data[index].m_value);
				theta_index[j].push_back(index);
			}
		}

		if(scanMethod == Linear) {
			float min = (*samples)[sorted_data.front().m_index]->getData(j);
			float max = (*samples)[sorted_data.back().m_index]->getData(j);
			float binStep = (max - min) / (numTheta + 2);

			for(unsigned int i = 0; i < numTheta; i++) {
				float theta_val = min + (i + 1) * binStep;

				size_t index = binary_find(sorted_data, 0, sorted_data.size() - 1, theta_val);
				while(index < m_v->getN() - 1 && sorted_data[index].m_value == sorted_data[index + 1].m_value)
					++index;

				theta[j].push_back(sorted_data[index].m_value);
				theta_index[j].push_back(index);
			}

		}

		if(scanMethod == Boundaries) {
			std::vector<std::set<size_t> >boundaries(m_v->getC());

			for(size_t i = 0; i < sorted_data.size() - 1; ++i) {
				size_t curInd = sorted_data[i].m_index;
				size_t nextInd = sorted_data[i + 1].m_index;

				const size_t curClass = (*samples)[curInd]->getTargetClass();
				const size_t nextClass = (*samples)[nextInd]->getTargetClass();

				if( curClass != nextClass ) {
					for(size_t ind = i; ind <= i + 1; ++ind) {
						size_t index = ind;
						while(index < m_v->getN() - 1 && sorted_data[index].m_value == sorted_data[index + 1].m_value)
							++index;
						boundaries[curClass].insert(index);
						boundaries[nextClass].insert(index);

						index = ind;
						while(index >= 1 && sorted_data[index].m_value == sorted_data[index - 1].m_value)
							--index;

						if(index != 0) {
							boundaries[curClass].insert(index - 1);
							boundaries[nextClass].insert(index - 1);
						}
					}
				}
			}

			for(size_t c = 0; c < m_v->getC(); ++c) {

	    		if (background[c])
	    			continue;

				for( std::set<size_t>::const_iterator i = boundaries[c].begin(); i != boundaries[c].end(); ++i ) {
					theta_class[c][j].push_back( sorted_data[*i].m_value );
					theta_class_index[c][j].push_back( *i );
				}
			}


			if (outStream) {
				(*outStream) << "\tMin: " << (*samples)[sorted_data.front().m_index]->getData(j) << " Max: " << (*samples)[sorted_data.back().m_index]->getData(j) << endl;

				(*outStream) << "Number of class boundaries: " << std::endl;
				(*outStream) << "============================" << std::endl;
				(*outStream) << "Dimension: " << j << std::endl;
				for(size_t i = 0; i < boundaries.size(); ++i)
					(*outStream) << "Class " << i << ": " << boundaries[i].size() << std::endl;
			}
		}

	}
	if (outStream)
		(*outStream) << "===========================================================" << endl;
}
void JointBoostClassifier::trainClassifier(Data* TrainingData, const BoostingParam& boost_param, std::ostream *outStream) {
	m_v = TrainingData;
	const vector<FeatureVector*>* samples = m_v->getAllSamples();

	if (outStream) {
		(*outStream) << "===========================================================" << endl;
		(*outStream) << "Starting to learn an ensemble classifier..." << endl;
		(*outStream) << "Boosting rounds: " << boost_param.numRounds << endl;
		(*outStream) << "Number of classes: " << m_v->getC() << endl;
		(*outStream) << "Data dimensionality: " << m_v->getD() << endl;
		for (size_t i = 0; i < m_v->getC(); i++)
			(*outStream) << "# Training instances for class " << i << ": " << m_v->getSamplesOfClass(i)->size() << endl;
		(*outStream) << "===========================================================" << endl;
	}

	srand(boost_param.randomSeed);

	//Copy the background class flags
	background.resize(m_v->getC(), false);
	numbg = 0;
	for(size_t i = 0; i < m_v->getC(); ++i) {
		background[i] = m_v->isBackground(i);
		if(background[i])
			++numbg;
	}

	if(boost_param.jb_theta_scan != Full || boost_param.IndexedTraining)
		prepareIndex(outStream, boost_param.IndexedTraining, boost_param.jb_theta_scan, boost_param.jb_num_theta);

	//Initialize weights
	std::vector<float> N_c(m_v->getC(), 0.0f);
	for(size_t i = 0; i < m_v->getN(); ++i) {
		const size_t sampleClassID = (*m_v->getAllSamples())[i]->getTargetClass();
		N_c[sampleClassID] += (*samples)[i]->getInstanceWeight(); //m_v->getSamplesOfClass(c)->size();
	}

	float N_w = 0.0f;
	for(size_t c = 0; c < m_v->getC(); ++c) {
		N_w += N_c[c];
	}


	weights.clear();
	for(size_t c = 0; c < m_v->getC(); ++c) {
		std::vector<float> we;
		weights.push_back(we);

		//For background classes we don't need weights.. so skip them..
		if(background[c])
			continue;

		for(size_t i = 0; i < m_v->getN(); ++i) {
			float w = 1.0f;
			const size_t sampleClassID = (*m_v->getAllSamples())[i]->getTargetClass();

			switch (boost_param.jb_weight_initialization) {

				case AllTheSame: {
					w = 1.0f * m_v->getClassWeight(sampleClassID) * (*samples)[i]->getInstanceWeight() / N_w;
					break;
				}

				case Pos50NegAllEqual: {
					if (sampleClassID == c)
						w = 0.5f * m_v->getClassWeight(sampleClassID) * (*samples)[i]->getInstanceWeight() / N_c[sampleClassID];
					else
						w = 0.5f * m_v->getClassWeight(sampleClassID) * (*samples)[i]->getInstanceWeight() / (N_w - N_c[c]);
					break;
				}

				case Pos50NegClassEqual: {
					if (sampleClassID == c)
						w = 0.5f * m_v->getClassWeight(sampleClassID) * (*samples)[i]->getInstanceWeight() / N_c[sampleClassID];
					else
						w = 0.5f / (m_v->getC() - 1) * m_v->getClassWeight(sampleClassID) * (*samples)[i]->getInstanceWeight() / N_c[sampleClassID];
					break;
				}
			}
			weights[c].push_back(w);
		}
	}

	//Initialize ensembles
	ensemble.clear();
	for(size_t j = 0; j < m_v->getC(); j++) {
		vector<size_t> rs;
		ensemble.push_back(rs);
	}
	stumps.clear();

	//Allocate Memory for precomputations
	if(boost_param.jb_theta_scan == Quantiles || boost_param.jb_theta_scan == Linear) {
		b_c.resize(m_v->getD());
		a_c.resize(m_v->getD());
		w_cplus.resize(m_v->getD());
		w_cminus.resize(m_v->getD());
		for(size_t i = 0; i < m_v->getD(); i++) {
			b_c[i].resize(m_v->getC());
			a_c[i].resize(m_v->getC());
			w_cplus[i].resize(m_v->getC());
			w_cminus[i].resize(m_v->getC());
		}

		for(size_t i = 0; i < m_v->getD(); i++) {
			for(size_t j = 0; j < m_v->getC(); j++) {

				if(background[j])
					continue;

				b_c[i][j].resize(theta[i].size());
				a_c[i][j].resize(theta[i].size());
				w_cplus[i][j].resize(theta[i].size());
				w_cminus[i][j].resize(theta[i].size());
			}
		}
	}

	if( boost_param.jb_theta_scan == Full || boost_param.jb_theta_scan == Boundaries || boost_param.jb_refine_withFullScan){
		b_c_full.resize(m_v->getC());
		a_c_full.resize(m_v->getC());
		w_cplus_full.resize(m_v->getC());
		w_cminus_full.resize(m_v->getC());

		for(size_t j = 0; j < m_v->getC(); j++) {

			if(background[j])
				continue;

			b_c_full[j].resize(m_v->getN());
			a_c_full[j].resize(m_v->getN());
			w_cplus_full[j].resize(m_v->getN());
			w_cminus_full[j].resize(m_v->getN());
		}
	}

	z.resize(m_v->getC());
	for(size_t c = 0; c < m_v->getC(); c++) {
		z[c].resize(m_v->getN());
		for(size_t i = 0; i < m_v->getN(); i++)
			z[c][i] = ((*samples)[i]->getTargetClass() == static_cast<int>(c) ? 1.0 : -1.0);
	}

	//Init local variables
	k.clear();
	k_n.clear();
	k_d.clear();
	l.clear();
	for (size_t c = 0; c < m_v->getC(); c++) {
		k.push_back(0.0);
		k_n.push_back(0.0);
		k_d.push_back(0.0);
		l.push_back(0.0);
	}

	//Assert we are in [0,1]
	subSampleRate = std::min(1.0f, std::fabs(boost_param.subSampleRate));
	numberSamples = static_cast<size_t>(ceilf(m_v->getD() * boost_param.subSampleRate ));

	//A list of all dimensions to draw from
	fullPool = std::vector<size_t>(m_v->getD());
	sampledPool = std::vector<size_t>(numberSamples);
	for(size_t i = 0; i < m_v->getD(); ++i)
		fullPool[i] = i;

	performRounds(boost_param.numRounds, boost_param, 0, outStream);

	computeSigmoidParams(m_v, outStream);
}

float JointBoostClassifier::computeError(Data* ValidationData, std::ostream *outStream) {
	const std::vector<FeatureVector*>* allSamples(ValidationData->getAllSamples());

	float error = 0;
	for(size_t i = 0; i < allSamples->size(); ++i) {

		std::vector<float> margin = evaluateFeaturePoint( (*(*allSamples)[i] ), None );

		for(size_t c = 0; c < ValidationData->getC(); ++c) {

			if(background[c])
				continue;

			if((*allSamples)[i]->getTargetClass() == static_cast<int>(c) )
				error+= std::exp(-margin[c]);
			else
				error+= std::exp(margin[c]);
		}
	}

	if (outStream)
		(*outStream) << "Classification error: " << error << std::endl;

	return error;
}


void JointBoostClassifier::performRounds(unsigned int numRounds, const BoostingParam& boost_param, Data* TrainingData, std::ostream *outStream, size_t roundOffset) {
	if(TrainingData)
		m_v = TrainingData;

	if (!m_v) {
		cout << "No training data available!" << endl;
		return;
	}

	for(unsigned int m = 0; m < numRounds; m++) {
		if (outStream) {
			(*outStream) << "Performing boosting round number: " << m + roundOffset;
			 std::flush(*outStream);
		}

		//Sample dimensions if subSampleRate != 1.0
		std::vector<size_t>* chosenFeatures;
		if(subSampleRate != 1.0) {
			size_t maxF = m_v->getD() - 1;

			for(size_t i = 0; i < numberSamples; ++i, --maxF) {
				size_t index = static_cast<size_t>(roundf(maxF * (rand() *  1.0f / RAND_MAX)));
				sampledPool[i] = fullPool[index];
				std::swap(fullPool[index], fullPool[maxF]);
			}

			chosenFeatures = &sampledPool;
		} else {
			chosenFeatures = &fullPool;
		}

		static RegressionStump addedStump;
		if(boost_param.jb_theta_scan == Quantiles || boost_param.jb_theta_scan == Linear) {
			if (m == 0)
				precomputeErrorFunctionAndK(0, boost_param.IndexedTraining);
			else
				precomputeErrorFunctionAndK(&addedStump.S, boost_param.IndexedTraining);
		} else {
			precomputeK();
		}

		for(size_t d = 0; d < chosenFeatures->size(); d++) {
			RegressionStump bestStumpForDimension;

			if(boost_param.jb_theta_scan == Quantiles || boost_param.jb_theta_scan == Linear) {
				bestStumpForDimension = findBestSubset((*chosenFeatures)[d]);
			} else {

				if (boost_param.jb_theta_scan == Full) {
					if(boost_param.IndexedTraining)
						precomputeAandB_fullScan_Indexed((*chosenFeatures)[d]);
					else
						precomputeAandB_fullScan_NonIndexed((*chosenFeatures)[d]);

					bestStumpForDimension = findBestSubset_fullScan(boost_param.IndexedTraining, (*chosenFeatures)[d]);
				}

				if (boost_param.jb_theta_scan == Boundaries) {
					if(boost_param.IndexedTraining)
						precomputeAandB_boundaries_Indexed((*chosenFeatures)[d]);
					else
						precomputeAandB_boundaries_NonIndexed((*chosenFeatures)[d]);

					bestStumpForDimension = findBestSubset_boundaries((*chosenFeatures)[d]);
				}
			}

			//If we do better than with previous stumps keep stump for dimension d
			if (bestStumpForDimension.J_wse < addedStump.J_wse || d == 0) {
				addedStump = bestStumpForDimension;
				addedStump.f = (*chosenFeatures)[d];
				addedStump.k = k;
			}
		}

		//Refine with a full scan on the selected dimension
		if(boost_param.jb_theta_scan != Full && boost_param.jb_refine_withFullScan) {
			if (outStream) {
				(*outStream) << " refining..";
				 std::flush(*outStream);
			}

			int dim = addedStump.f;

			if(boost_param.IndexedTraining)
				precomputeAandB_fullScan_Indexed(dim);
			else
				precomputeAandB_fullScan_NonIndexed(dim);

			addedStump = findBestSubset_fullScan(boost_param.IndexedTraining, dim);

			addedStump.f = dim;
			addedStump.k = k;
		}

		if (outStream) {
			(*outStream) << " a: " << addedStump.a << ", b: " << addedStump.b << ", dim: " << addedStump.f <<  ", Error: " << addedStump.J_wse << ", Theta: " << addedStump.theta << std::endl;
		}

		//add the stump
		stumps.push_back(addedStump);
		for(size_t c = 0; c < m_v->getC(); c++) {
			if (addedStump.S.contains(c))
				ensemble[c].push_back(stumps.size() - 1);
		}

		//update weights[c,i]
		const vector<FeatureVector*>* samples = m_v->getAllSamples();

		for(size_t c = 0; c < m_v->getC(); c++) {
			if (!addedStump.S.contains(c))
				continue;

			for(size_t i = 0; i < m_v->getN(); i++) {
				float h = (*samples)[i]->getData(addedStump.f) > addedStump.theta ? addedStump.a : addedStump.b;
				weights[c][i] = weights[c][i] * std::exp(-1.0f * h * z[c][i]);
			}
		}
	}

	computeNormalizers();
}

void JointBoostClassifier::computeNormalizers() {
	// Collect information for score normalizing

	bool firstNonBg = true;

	for(size_t c = 0; c < ensemble.size(); ++c) {

		if(background[c])
			continue;

		float minV = 0.0f;
		float maxV = 0.0f;
		for(size_t s = 0; s < stumps.size(); ++s) {
			if(!stumps[s].S.contains(c))
				continue;

			minV += std::min( stumps[s].a, stumps[s].b );
			maxV += std::max( stumps[s].a, stumps[s].b );
		}

		// Use lowest range per class for normalization
		if ( (maxV - minV) < scoreNorm || firstNonBg) {
			minScore = minV;
			scoreNorm = (maxV - minV);
			firstNonBg = false;
		}

		//std::cout << "Class " << c << ": " << minV << "-" << maxV << std::endl;
	}

	scoreNorm = 1.0f / scoreNorm;
}

void JointBoostClassifier::computeSigmoidParams(const Data* trainData, std::ostream *outStream) {

	if(outStream)
		(*outStream) << "Computing sigmoid paramters..." << std::endl;

	const std::vector<FeatureVector*>* allSamples = trainData->getAllSamples();

	std::vector<std::vector<float> > scores (trainData->getN(), std::vector<float>(trainData->getC()));

	for(size_t i = 0; i < allSamples->size() ; ++i) {
		 scores[i] = evaluateFeaturePoint( *(*allSamples)[i], None, false);
	}

	A.resize(trainData->getC());
	B.resize(trainData->getC());

	for(size_t c = 0; c < trainData->getC(); ++c) {

		if(background[c]) {
			A[c] = 1.0f;
			B[c] = 0.0f;
			continue;
		}

		std::vector<double> currentClassScore(trainData->getN());
		std::vector<double> label(trainData->getN());

		for(size_t i = 0; i < allSamples->size() ; ++i) {
			currentClassScore[i] = scores[i][c];

			if( (*allSamples)[i]->getTargetClass() == static_cast<int>(c) ) {
				label[i] = 1;
			} else {
				label[i] = -1;
			}
		}

		sigmoid_train(currentClassScore, label, A[c], B[c]);

		if(outStream)
			(*outStream) << "Class " << c << " A: " << A[c] << " B: " << B[c] << std::endl;

	}
}


float JointBoostClassifier::getMarginScaling(size_t classID) {
	// Collect information for score normalizing

	if(background[classID])
		return 0.0;

	float minV = 0.0f;
	float maxV = 0.0f;
	for(size_t s = 0; s < stumps.size(); ++s) {
		if(!stumps[s].S.contains(classID))
			continue;

		minV += std::min( stumps[s].a, stumps[s].b );
		maxV += std::max( stumps[s].a, stumps[s].b );
	}

	// Use lowest range per class for normalization
	return 0.5f / (((maxV + minV) / 2.0f - minScore) * scoreNorm);
}


//Efficient computation of shared regression stumps
void JointBoostClassifier::precomputeErrorFunctionAndK(SharingSet *lastS, bool IndexedTraining) {

	precomputeK();

	if(IndexedTraining)
		precomputeAandBIndexed(lastS);
	else
		precomputeAandBNonIndexed(lastS);
}

void JointBoostClassifier::precomputeK() {
	//Precompute K
	for(size_t c = 0; c < m_v->getC(); c++) {
		if(background[c])
			continue;

		k_n[c] = k_d[c] = k[c] = l[c] = 0 ;

		for(size_t i = 0; i < m_v->getN(); i++) {
			k_n[c] += weights[c][i] * z[c][i];
			k_d[c] +=  weights[c][i];
		}
		k[c] = k_n[c] / k_d[c];
		for(size_t i = 0; i < m_v->getN(); i++)
			l[c] += weights[c][i] * (z[c][i] - k[c]) *  (z[c][i] - k[c]);
	}
}

void JointBoostClassifier::precomputeAandBIndexed(SharingSet *lastS) {
	std::vector<float> cumWZ(m_v->getN(), 0.0);
    std::vector<float> cumW(m_v->getN(), 0.0);

	//Precompute a and b for leaf nodes
	for(size_t c = 0; c < m_v->getC(); c++) {

		if ( (lastS && !lastS->contains(c)) || background[c])
			continue;

		for(size_t d = 0; d < m_v->getD() ; d++) {
    		register float cWZ = 0.0f;
    		register float cW = 0.0f;
    		for(size_t i = 0; i < m_v->getN(); ++i) {
				cWZ += weights[c][sorted_index[d][i]] * z[c][sorted_index[d][i]];
    			cW += weights[c][sorted_index[d][i]];

    			cumWZ[i] = cWZ;
    			cumW[i] = cW;
    		}

    		for(unsigned int t = 0; t < theta[d].size(); t++) {
    			// We can just remember the indeces in the beginning
    			//size_t sorted_theta_ind = binary_find(*samples, sorted_index[dims[d]], dims[d], 0, m_v->getN(), theta[dims[d][t]);
    			//cout << sorted_theta_ind << " " << theta_index[dims[d]][t] << endl;

    			size_t& sorted_theta_ind = theta_index[d][t];

    			float b_n = cumWZ[sorted_theta_ind];
    			float b_d = cumW[sorted_theta_ind];
    			float a_n = cWZ - cumWZ[sorted_theta_ind];
    			float a_d = cW - cumW[sorted_theta_ind];

    			b_c[d][c][t] = b_n / b_d;
    			a_c[d][c][t] = a_n / a_d;
    			w_cplus[d][c][t] = a_d;
    			w_cminus[d][c][t] = b_d;
    		}
    	}
    }
}

void JointBoostClassifier::precomputeAandBNonIndexed(SharingSet *lastS) {
	const vector<FeatureVector*>* samples = m_v->getAllSamples();

	std::vector<float> cumWZ(m_v->getN(), 0.0);
    std::vector<float> cumW(m_v->getN(), 0.0);

	//Precompute a and b for leaf nodes
	for(size_t d = 0; d < m_v->getD(); ++d) {

		// If we don't have the global index we have to sort the elements here
		sorted_data.clear();
		sorted_data.reserve(m_v->getN());
		for(size_t i = 0; i < m_v->getN(); ++i) {
			sorted_data.push_back(BoostingDataPoint ( (*samples)[i]->getData(d), i ) );
		}
		std::sort(sorted_data.begin(), sorted_data.end());

		for(size_t c = 0; c < m_v->getC(); c++) {

			if ((lastS && !lastS->contains(c)) || background[c])
				continue;

    		register float cWZ = 0.0f;
    		register float cW = 0.0f;
    		for(size_t i = 0; i < m_v->getN(); ++i) {
				cWZ += weights[c][sorted_data[i].m_index] * z[c][sorted_data[i].m_index];
    			cW += weights[c][sorted_data[i].m_index];

    			cumWZ[i] = cWZ;
    			cumW[i] = cW;
    		}

    		for(unsigned int t = 0; t < theta[d].size(); t++) {
    			// We can just remember the indeces in the beginning
    			//size_t sorted_theta_ind = binary_find(*samples, sorted_index[dims[d]], dims[d], 0, m_v->getN(), theta[dims[d]][t]);
    			//cout << sorted_theta_ind << " " << theta_index[dims[d]][t] << endl;

    			size_t& sorted_theta_ind = theta_index[d][t];

    			float b_n = cumWZ[sorted_theta_ind];
    			float b_d = cumW[sorted_theta_ind];
    			float a_n = cWZ - cumWZ[sorted_theta_ind];
    			float a_d = cW - cumW[sorted_theta_ind];

    			b_c[d][c][t] = b_n / b_d;
    			a_c[d][c][t] = a_n / a_d;
    			w_cplus[d][c][t] = a_d;
    			w_cminus[d][c][t] = b_d;
    		}
    	}
    }
}

void JointBoostClassifier::precomputeAandB_fullScan_NonIndexed(size_t d) {
	const vector<FeatureVector*>* samples = m_v->getAllSamples();

	//Precompute a and b for leaf nodes
	// If we don't have the global index we have to sort the elements here

	sorted_data.clear();
	sorted_data.reserve(m_v->getN());
	for(size_t i = 0; i < m_v->getN(); ++i) {
		sorted_data.push_back(BoostingDataPoint ( (*samples)[i]->getData(d), i ) );
	}
	std::sort(sorted_data.begin(), sorted_data.end());

	for(size_t c = 0; c < m_v->getC(); c++) {

		if (background[c])
			continue;

    	register float cWZ = 0.0f;
    	register float cW = 0.0f;
    	for(size_t i = 0; i < m_v->getN(); ++i) {
			cWZ += weights[c][sorted_data[i].m_index] * z[c][sorted_data[i].m_index];
    		cW += weights[c][sorted_data[i].m_index];
    	}

    	register float b_n = 0.0f;
    	register float b_d = 0.0f;

    	for(unsigned int t = 0; t < m_v->getN(); ++t) {

				b_n += weights[c][sorted_data[t].m_index] * z[c][sorted_data[t].m_index];
    		    b_d += weights[c][sorted_data[t].m_index];

    			float a_n = cWZ - b_n;
    			float a_d = cW - b_d;

    			b_c_full[c][t] = b_n / b_d;
    			a_c_full[c][t] = a_n / a_d;
    			w_cplus_full[c][t] = a_d;
    			w_cminus_full[c][t] = b_d;
    	}
    }
}

void JointBoostClassifier::precomputeAandB_fullScan_Indexed(size_t d) {
	//Precompute a and b for leaf nodes
	// If we don't have the global index we have to sort the elements here

	for(size_t c = 0; c < m_v->getC(); c++) {

		if (background[c])
			continue;

    	register float cWZ = 0.0f;
    	register float cW = 0.0f;
    	for(size_t i = 0; i < m_v->getN(); ++i) {
			cWZ += weights[c][sorted_index[d][i]] * z[c][sorted_index[d][i]];
    		cW += weights[c][sorted_index[d][i]];
    	}

    	register float b_n = 0.0f;
    	register float b_d = 0.0f;

    	for(unsigned int t = 0; t < m_v->getN(); ++t) {

			b_n += weights[c][sorted_index[d][t]] * z[c][sorted_index[d][t]];
    		b_d += weights[c][sorted_index[d][t]];

    		float a_n = cWZ - b_n;
    		float a_d = cW - b_d;

    		b_c_full[c][t] = b_n / b_d;
    		a_c_full[c][t] = a_n / a_d;
    		w_cplus_full[c][t] = a_d;
    		w_cminus_full[c][t] = b_d;
    	}
    }
}

void JointBoostClassifier::precomputeAandB_boundaries_NonIndexed(size_t d) {
	const vector<FeatureVector*>* samples = m_v->getAllSamples();

	//Precompute a and b for leaf nodes
	// If we don't have the global index we have to sort the elements here

	sorted_data.clear();
	sorted_data.reserve(m_v->getN());
	for(size_t i = 0; i < m_v->getN(); ++i) {
		sorted_data.push_back(BoostingDataPoint ( (*samples)[i]->getData(d), i ) );
	}
	std::sort(sorted_data.begin(), sorted_data.end());

	for(size_t c = 0; c < m_v->getC(); c++) {

		if (background[c])
			continue;

    	register float cWZ = 0.0f;
    	register float cW = 0.0f;

    	std::vector<float> b_n(m_v->getN());
    	std::vector<float> b_d(m_v->getN());

    	for(size_t i = 0; i < m_v->getN(); ++i) {
			cWZ += weights[c][sorted_data[i].m_index] * z[c][sorted_data[i].m_index];
    		cW += weights[c][sorted_data[i].m_index];

    		b_n[i] += cWZ;
        	b_d[i] += cW;
    	}

    	for(size_t tc = 0; tc < m_v->getC(); ++tc) {
    		for(unsigned int t = 0; t < theta_class[tc].size(); ++t) {
    			size_t& ind = theta_class_index[tc][d][t];

    			float a_n = cWZ - b_n[ind];
    			float a_d = cW - b_d[ind];

    			b_c_full[c][ind] = b_n[ind] / b_d[ind];
    			a_c_full[c][ind] = a_n / a_d;
    			w_cplus_full[c][ind] = a_d;
    			w_cminus_full[c][ind] = b_d[ind];
			}
    	}
    }
}

void JointBoostClassifier::precomputeAandB_boundaries_Indexed(size_t d) {
	//Precompute a and b for leaf nodes
	// If we don't have the global index we have to sort the elements here

	for(size_t c = 0; c < m_v->getC(); c++) {

		if (background[c])
			continue;

    	register float cWZ = 0.0f;
    	register float cW = 0.0f;

    	std::vector<float> b_n(m_v->getN());
    	std::vector<float> b_d(m_v->getN());

    	for(size_t i = 0; i < m_v->getN(); ++i) {
			cWZ += weights[c][sorted_index[d][i]] * z[c][sorted_index[d][i]];
    		cW += weights[c][sorted_index[d][i]];
    		b_n[i] += cWZ;
        	b_d[i] += cW;
    	}

    	for(size_t tc = 0; tc < m_v->getC(); ++tc) {
    		for(unsigned int t = 0; t < theta_class[tc].size(); ++t) {
    			size_t& ind = theta_class_index[tc][d][t];

    			float a_n = cWZ - b_n[ind];
    			float a_d = cW - b_d[ind];

    			b_c_full[c][ind] = b_n[ind] / b_d[ind];
    			a_c_full[c][ind] = a_n / a_d;
    			w_cplus_full[c][ind] = a_d;
    			w_cminus_full[c][ind] = b_d[ind];
    		}
    	}
    }
}

//Efficient search for the best sharing
RegressionStump JointBoostClassifier::findBestSubset(size_t d) {
	SharingSet S;
	RegressionStump m_stumps[m_v->getC() - numbg];

	//Remember some intermediate value to speed up error calculation by exploiting sharing tree structure
	float error = 0;
	for(size_t a = 0; a < m_v->getC(); a++) {
		if(!background[a])
			error += l[a];
	}

	std::vector<float>a_n(theta[d].size(), 0.0);
	std::vector<float>b_n(theta[d].size(), 0.0);
	std::vector<float>a_d(theta[d].size(), 0.0);
	std::vector<float>b_d(theta[d].size(), 0.0);

	//Add all classes subsequently to the sharing set in the order of the highest error reduction
	for(size_t c = 0; c < m_v->getC() - numbg; c++) {
		int bestErrorReduceClass = 0;
		RegressionStump bestStump;
		bestStump.J_wse = -1;

		for(size_t a = 0; a < m_v->getC(); a++) {
			if (S.contains(a) || background[a])
				continue;
			SharingSet testSet = SharingSet(S, a);

			RegressionStump r = getBestWeakLearner(testSet, d, error, a, a_n, b_n, a_d, b_d);

			if (r.J_wse < bestStump.J_wse || bestStump.J_wse == -1) {
				bestErrorReduceClass = a;
				bestStump = r;
			}
		}

		S = SharingSet(S, bestErrorReduceClass);
		for(unsigned int t = 0; t < theta[d].size(); t++) {
			a_n[t] = a_n[t] + a_c[d][bestErrorReduceClass][t] * w_cplus[d][bestErrorReduceClass][t];
			a_d[t] = a_d[t] + w_cplus[d][bestErrorReduceClass][t];
			b_n[t] = b_n[t] + b_c[d][bestErrorReduceClass][t] * w_cminus[d][bestErrorReduceClass][t];
			b_d[t] = b_d[t] + w_cminus[d][bestErrorReduceClass][t];
		}
		error = error - l[bestErrorReduceClass];
		m_stumps[c] = bestStump;
	}

	int best = 0;
	for(size_t c = 1; c < m_v->getC() - numbg; c++)
		if (m_stumps[c].J_wse < m_stumps[best].J_wse) best = c;

	return m_stumps[best];
}

//Efficient search for the best sharing
RegressionStump JointBoostClassifier::findBestSubset_fullScan(bool indexed, size_t d) {
	SharingSet S;
	RegressionStump m_stumps[m_v->getC() - numbg];

	//Remember some intermediate value to speed up error calculation by exploiting sharing tree structure
	float error = 0;
	for(size_t a = 0; a < m_v->getC(); a++) {
		if(!background[a])
			error += l[a];
	}

	std::vector<float>a_n(m_v->getN(), 0.0);
	std::vector<float>b_n(m_v->getN(), 0.0);
	std::vector<float>a_d(m_v->getN(), 0.0);
	std::vector<float>b_d(m_v->getN(), 0.0);

	//Add all classes subsequently to the sharing set in the order of the highest error reduction
	for(size_t c = 0; c < m_v->getC() - numbg; c++) {
		int bestErrorReduceClass = 0;
		RegressionStump bestStump;
		bestStump.J_wse = -1;

		for(size_t a = 0; a < m_v->getC(); a++) {
			if (S.contains(a) || background[a])
				continue;
			SharingSet testSet = SharingSet(S, a);

			RegressionStump r = getBestWeakLearner_fullScan(testSet, indexed, d, error, a, a_n, b_n, a_d, b_d);

			if (r.J_wse < bestStump.J_wse || bestStump.J_wse == -1) {
				bestErrorReduceClass = a;
				bestStump = r;
			}
		}

		S = SharingSet(S, bestErrorReduceClass);
		for(unsigned int t = 0; t < m_v->getN(); t++) {
			a_n[t] = a_n[t] + a_c_full[bestErrorReduceClass][t] * w_cplus_full[bestErrorReduceClass][t];
			a_d[t] = a_d[t] + w_cplus_full[bestErrorReduceClass][t];
			b_n[t] = b_n[t] + b_c_full[bestErrorReduceClass][t] * w_cminus_full[bestErrorReduceClass][t];
			b_d[t] = b_d[t] + w_cminus_full[bestErrorReduceClass][t];
		}
		error = error - l[bestErrorReduceClass];
		m_stumps[c] = bestStump;
	}

	int best = 0;
	for(size_t c = 1; c < m_v->getC() - numbg; c++)
		if (m_stumps[c].J_wse < m_stumps[best].J_wse) best = c;

	return m_stumps[best];
}

RegressionStump JointBoostClassifier::findBestSubset_boundaries(size_t d) {
	SharingSet S;
	RegressionStump m_stumps[m_v->getC() - numbg];

	//Remember some intermediate value to speed up error calculation by exploiting sharing tree structure
	float error = 0;
	for(size_t a = 0; a < m_v->getC(); a++) {
		if(!background[a])
			error += l[a];
	}

	std::vector<float>a_n(m_v->getN(), 0.0);
	std::vector<float>b_n(m_v->getN(), 0.0);
	std::vector<float>a_d(m_v->getN(), 0.0);
	std::vector<float>b_d(m_v->getN(), 0.0);

	//Add all classes subsequently to the sharing set in the order of the highest error reduction
	for(size_t c = 0; c < m_v->getC() - numbg; c++) {
		int bestErrorReduceClass = 0;
		RegressionStump bestStump;
		bestStump.J_wse = -1;

		for(size_t a = 0; a < m_v->getC(); a++) {
			if (S.contains(a) || background[a])
				continue;
			SharingSet testSet = SharingSet(S, a);

			RegressionStump r = getBestWeakLearner_boundaries(testSet, d, error, a, a_n, b_n, a_d, b_d);

			if (r.J_wse < bestStump.J_wse || bestStump.J_wse == -1) {
				bestErrorReduceClass = a;
				bestStump = r;
			}
		}

		S = SharingSet(S, bestErrorReduceClass);
		for(size_t tc = 0; tc < m_v->getC(); ++tc) {
		    for(unsigned int t = 0; t < theta_class[tc].size(); ++t) {
		    	size_t& ind = theta_class_index[tc][d][t];

		    	a_n[ind] = a_n[ind] + a_c_full[bestErrorReduceClass][ind] * w_cplus_full[bestErrorReduceClass][ind];
		    	a_d[ind] = a_d[ind] + w_cplus_full[bestErrorReduceClass][ind];
		    	b_n[ind] = b_n[ind] + b_c_full[bestErrorReduceClass][ind] * w_cminus_full[bestErrorReduceClass][ind];
		    	b_d[ind] = b_d[ind] + w_cminus_full[bestErrorReduceClass][ind];
		    }
		}
		error = error - l[bestErrorReduceClass];
		m_stumps[c] = bestStump;
	}

	int best = 0;
	for(size_t c = 1; c < m_v->getC() - numbg; c++)
		if (m_stumps[c].J_wse < m_stumps[best].J_wse) best = c;

	return m_stumps[best];
}



RegressionStump JointBoostClassifier::getBestWeakLearner(const SharingSet& S, size_t d, float errorTerm, size_t lastAdded, const std::vector<float> &a_n, const std::vector<float> &b_n,const std::vector<float> &a_d, const std::vector<float> &b_d) {
	RegressionStump r;
	r.J_wse = -1;

	 //Try all valid thetas
	for(size_t t = 0; t < theta[d].size(); t++) {
		//Evaluate error
		float b_s_n = b_n[t] + b_c[d][lastAdded][t] * w_cminus[d][lastAdded][t];
		float b_s_d = b_d[t] + w_cminus[d][lastAdded][t];
		float a_s_n = a_n[t] +  a_c[d][lastAdded][t] * w_cplus[d][lastAdded][t];
		float a_s_d = a_d[t] + w_cplus[d][lastAdded][t];

		float a_s = a_s_n / a_s_d;
		float b_s = b_s_n / b_s_d;

		float J = (1 - a_s * a_s) * a_s_d + (1 - b_s * b_s) * b_s_d + errorTerm - l[lastAdded];

		if (J < r.J_wse || r.J_wse == -1) {
			r.a = a_s;
			r.b = b_s;
			r.theta = theta[d][t];
			r.J_wse = J;
			r.S = S;
		}
	}
	return r;
}

RegressionStump JointBoostClassifier::getBestWeakLearner_fullScan(const SharingSet& S, bool indexed, size_t d, float errorTerm, size_t lastAdded, const std::vector<float> &a_n, const std::vector<float> &b_n,const std::vector<float> &a_d, const std::vector<float> &b_d) {
	const vector<FeatureVector*>* samples = m_v->getAllSamples();

	RegressionStump r;
	r.J_wse = -1;

	//Try all valid thetas
	// Duplicated code to avoid to many ifs
	if (!indexed) {
		for(size_t t = 0; t < m_v->getN(); t++) {
			//Evaluate error
			float b_s_n = b_n[t] + b_c_full[lastAdded][t] * w_cminus_full[lastAdded][t];
			float b_s_d = b_d[t] + w_cminus_full[lastAdded][t];
			float a_s_n = a_n[t] +  a_c_full[lastAdded][t] * w_cplus_full[lastAdded][t];
			float a_s_d = a_d[t] + w_cplus_full[lastAdded][t];

			float a_s = a_s_n / a_s_d;
			float b_s = b_s_n / b_s_d;

			float J = (1 - a_s * a_s) * a_s_d + (1 - b_s * b_s) * b_s_d + errorTerm - l[lastAdded];

			if (J < r.J_wse || r.J_wse == -1) {
				if(t < m_v->getN() - 1 && sorted_data[t].m_value == sorted_data[t + 1].m_value)
					continue;
				r.theta = sorted_data[t].m_value;
				r.a = a_s;
				r.b = b_s;
				r.J_wse = J;
				r.S = S;
			}
		}
	} else {
		for(size_t t = 0; t < m_v->getN(); t++) {
			//Evaluate error
			float b_s_n = b_n[t] + b_c_full[lastAdded][t] * w_cminus_full[lastAdded][t];
			float b_s_d = b_d[t] + w_cminus_full[lastAdded][t];
			float a_s_n = a_n[t] +  a_c_full[lastAdded][t] * w_cplus_full[lastAdded][t];
			float a_s_d = a_d[t] + w_cplus_full[lastAdded][t];

			float a_s = a_s_n / a_s_d;
			float b_s = b_s_n / b_s_d;

			float J = (1 - a_s * a_s) * a_s_d + (1 - b_s * b_s) * b_s_d + errorTerm - l[lastAdded];

			if (J < r.J_wse || r.J_wse == -1) {
				if(t < m_v->getN() - 1 && (*samples)[sorted_index[d][t]]->getData(d) == (*samples)[sorted_index[d][t + 1]]->getData(d))
					continue;
				r.theta = (*samples)[sorted_index[d][t]]->getData(d);

				r.a = a_s;
				r.b = b_s;
				r.J_wse = J;
				r.S = S;
			}
		}
	}

	return r;
}

RegressionStump JointBoostClassifier::getBestWeakLearner_boundaries(const SharingSet& S, size_t d, float errorTerm, size_t lastAdded, const std::vector<float> &a_n, const std::vector<float> &b_n,const std::vector<float> &a_d, const std::vector<float> &b_d) {

	RegressionStump r;
	r.J_wse = -1;

	//Try all thetas at class boundaries
	for(size_t c = 0; c < m_v->getC(); ++c) {
    	if(!S.contains(c))
    		continue;

    	for(unsigned int t = 0; t < theta_class[c].size(); ++t) {
    		size_t& ind = theta_class_index[c][d][t];

    		//Evaluate error
    		float b_s_n = b_n[ind] + b_c_full[lastAdded][ind] * w_cminus_full[lastAdded][ind];
    		float b_s_d = b_d[ind] + w_cminus_full[lastAdded][ind];
    		float a_s_n = a_n[ind] +  a_c_full[lastAdded][ind] * w_cplus_full[lastAdded][ind];
    		float a_s_d = a_d[ind] + w_cplus_full[lastAdded][ind];

    		float a_s = a_s_n / a_s_d;
    		float b_s = b_s_n / b_s_d;

    		float J = (1 - a_s * a_s) * a_s_d + (1 - b_s * b_s) * b_s_d + errorTerm - l[lastAdded];

    		if (J < r.J_wse || r.J_wse == -1) {
    			r.theta = theta_class[c][d][t];
    			r.a = a_s;
    			r.b = b_s;
    			r.J_wse = J;
    			r.S = S;
    		}
    	}
    }

	return r;
}

vector<float> JointBoostClassifier::evaluateFeaturePoint(const FeatureVector &v, Boosting_Normalization normalize, bool softmax, unsigned int rounds) {
	vector<float> classes(ensemble.size());

	size_t activeStumps = stumps.size();
	if(rounds != 0)
		activeStumps = rounds;

	// Evaluate all features
	for(unsigned int i = 0; i < activeStumps; i++) {
		float val = v.getData(stumps[i].f);
		stumps[i].value = (val > stumps[i].theta ? stumps[i].a : stumps[i].b);
	}

	//Combine features according to sharing sets
	float sumH = 0;
	for(unsigned int c = 0; c < ensemble.size(); c++) {

		if(background[c]) {
			classes[c] = 0;
			continue;
		}

		register float H = 0;
		for(unsigned int l = 0; l < ensemble[c].size(); l++)
			if (ensemble[c][l] < activeStumps) {
				H += stumps[ensemble[c][l]].value;
			}

		switch(normalize) {
			case Ratio: {
				H = (H - minScore) * scoreNorm;
				break;
			}

			case Sigmoid: {
				register float fApB = H * A[c] + B[c];
				if (fApB >= 0)
					H = std::exp(-fApB)/(1.0f + std::exp(-fApB));
				else
					H = 1.0f /(1.0f + std::exp(fApB));
				break;
			}

			default:
				break;
		}

		if(!softmax) {
			classes[c] = H;
		} else {
			classes[c] = std::exp(H);
			sumH += classes[c];
		}
	}

	if (softmax) {
		sumH = 1.0f / sumH;
		for(unsigned int c = 0; c < ensemble.size(); c++)
			classes[c] *= sumH;
	}


	return classes;
}

void JointBoostClassifier::printEnsembles() {
	for(unsigned int c = 0; c < ensemble.size(); c++) {
		cout << "Classifier for class " << c << ": " << endl;
		for(unsigned int e = 0; e < ensemble[c].size(); e++) {
			cout << "Feature number: " << stumps[ensemble[c][e]].f << endl;
			cout << "a: " << stumps[ensemble[c][e]].a - stumps[ensemble[c][e]].b << endl;
			cout << "b: " << stumps[ensemble[c][e]].b << endl;
			cout << "Theta: " << stumps[ensemble[c][e]].theta << endl;
			cout << "Shared by: ";
			for(unsigned int j = 0; j < ensemble.size(); j++)
				if (stumps[ensemble[c][e]].S.contains(j))
					cout << j << ' ';
			cout << endl;
			cout << "---------------------------------------------" << endl;
		}
		float sumK = 0;
		for(unsigned int i = 0; i < stumps.size(); i++)
			if (!stumps[i].S.contains(c))
				sumK += stumps[i].k[c];
		cout << "sum k^c: " << sumK << endl;
		cout << "================================================================" << endl;
	}
}

void JointBoostClassifier::printAllStumps() {
	for(unsigned int s = 0; s < stumps.size(); s++) {
		cout << "Stump number: " << s << ": " << endl;
		cout << "Feature number: " << stumps[s].f << endl;
		cout << "a: " << stumps[s].a - stumps[s].b << endl;
		cout << "b: " << stumps[s].b << endl;
		cout << "Theta: " << stumps[s].theta << endl;
		cout << "Shared by: ";
		for(unsigned int j = 0; j < ensemble.size(); j++)
			if (stumps[s].S.contains(j))
				cout << j << ' ';
		cout << endl;
		cout << "================================================================" << endl;
	}
}

ostream& operator<<(ostream& output, JointBoostClassifier& jb) {
	try {
		output << setprecision(15) << jb.theta.size() << std::endl;
		output << setprecision(15) << jb.stumps.size() << "\t" << jb.stumps[0].k.size() << endl;

		for(size_t i = 0; i < jb.background.size(); ++i)
			output << static_cast<int>(jb.background[i]) << "\t";
		output << std::endl;

		for(unsigned int i = 0; i < jb.stumps.size(); i++) {
			output << jb.stumps[i].a << "\t" << jb.stumps[i].b << "\t" << jb.stumps[i].f << "\t" << jb.stumps[i].J_wse << "\t" << jb.stumps[i].theta << "\t" << jb.stumps[i].S.getSet() << "\t" << endl;
			for(unsigned j = 0; j < jb.stumps[i].k.size(); j++)
				output << jb.stumps[i].k[j] << "\t";
			output << endl;
		}

		for(size_t i = 0; i < jb.A.size(); ++i) {
			output << jb.A[i] << "\t" << jb.B[i] << endl;
		}

	} catch(iostream::failure) {
		cerr << "Could not write to stream...";
		throw;
	}
	return output;
}

istream& operator>>(istream& input, JointBoostClassifier& jb) {
	//Reset Data to make sure training data and classifier match
	jb.m_v = 0;
	jb.stumps.clear();
	jb.ensemble.clear();
	jb.theta.clear();
	try {
		unsigned int th;
		input >> th;

		//Restore number of classes and rounds, i.e. number of stumps
		size_t ns, nc;
		input >> ns >> nc;
		jb.ensemble.resize(nc);
		jb.stumps.resize(ns);

		//Restore background flags
		jb.background.resize(nc, false);
		for(size_t i = 0; i < nc; ++i) {
			int bg;
			input >> bg;
			jb.background[i] = static_cast<bool>(bg);
		}

		//Restore stumps
		for(unsigned int i = 0; i < ns; i++) {
			RegressionStump r;
			std::bitset<JB_MAXCLASSES> set;
			input >> r.a >> r.b >> r.f >> r.J_wse >> r.theta >> set;
			r.S = SharingSet(set);

			r.k.resize(nc);
			for(unsigned j = 0; j < nc; j++)
				input >> r.k[j];

			jb.stumps[i] = r;
			for(unsigned int j = 0; j < nc; j++)
				if (r.S.contains(j))
					jb.ensemble[j].push_back(i);
		}

		//Restore sigmoid params
		jb.A.resize(nc);
		jb.B.resize(nc);
		for(size_t i = 0; i < nc; ++i) {
			input >> jb.A[i];
			input >> jb.B[i];
		}

	} catch(iostream::failure) {
		cerr << "Could not read from stream..." << endl;
		throw;
	}

	jb.computeNormalizers();
	return input;
}

void JointBoostClassifier::loadClassifier(std::string filename) {
	ifstream f(filename.c_str());
	f >> (*this);
}

void JointBoostClassifier::saveClassifier(std::string filename) {
	if (!stumps.size()) return;

	ofstream f(filename.c_str());
	f << (*this);
}
