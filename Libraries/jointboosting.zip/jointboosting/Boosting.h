/*
 * Boosting.h
 *
 *  Created on: Nov 12, 2008
 *      Author: Christian Wojek
 */

#ifndef BOOSTING_H_
#define BOOSTING_H_

#include <BoostingData.h>

enum JB_Weighting {Pos50NegClassEqual, Pos50NegAllEqual, AllTheSame};
enum JB_Scanning {Full, Quantiles, Linear, Boundaries};
enum Boosting_Normalization {None, Sigmoid, Ratio};

struct BoostingParam {
	size_t numRounds;
	float subSampleRate;
	size_t randomSeed;
	bool IndexedTraining;
	bool fitSigmoid;

	size_t xv_n_folds;
	size_t xv_foldsUsed;
	size_t xv_interval;
	float  xv_maxIncrease;

	size_t jb_num_theta;
	JB_Weighting jb_weight_initialization;
	JB_Scanning jb_theta_scan;
	bool jb_refine_withFullScan;

	BoostingParam() :
		numRounds(100),
		subSampleRate(1.0),
		randomSeed(42),
		IndexedTraining(false),
		xv_n_folds(5),
		xv_foldsUsed(1),
		xv_interval(10),
		xv_maxIncrease(0.02),
		jb_num_theta(100),
		jb_weight_initialization(Pos50NegAllEqual),
		jb_theta_scan(Quantiles),
		jb_refine_withFullScan(true)
	{}
};


class BoostingAlgorithm {
public:
	void trainClassifierWithXV(Data* TrainingData, const BoostingParam& boost_param, std::ostream *outStream = 0);
	virtual void trainClassifier(Data* TrainingData, const BoostingParam& boost_param, std::ostream *outStream = 0) = 0;
	virtual void performRounds(unsigned int numRounds, const BoostingParam& boost_param, Data* TrainingData = 0, std::ostream *outStream = 0, size_t roundOffset = 0) = 0;
	virtual float computeError(Data* ValidationData, std::ostream *outStream = 0) = 0;
	virtual void loadClassifier(std::string filename) = 0;
	virtual void saveClassifier(std::string filename) = 0;
	virtual void sortModel() = 0;
	virtual ~BoostingAlgorithm() {}
protected:
	void sigmoid_train(const std::vector<double>& dec_values, const std::vector<double>& labels, double& A, double& B);
};

#endif /* BOOSTING_H_ */
