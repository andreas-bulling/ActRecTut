#ifndef ADABOOST_H_
#define ADABOOST_H_

/*
 *
 *  Implementation of Discrete Adaboost as described in Viola & Jones
 * in Robost Real-Time Face Detection, IJCV 2004
 *
 */

#include <iostream>
#include <algorithm>
#include <cmath>
#include <DecisionStump.h>
#include <BoostingData.h>
#include <Boosting.h>

class AdaBoostClassifier : public BoostingAlgorithm{
	friend std::ostream& operator<<(std::ostream& output, AdaBoostClassifier& ab);
	friend std::istream& operator>>(std::istream& input, AdaBoostClassifier& ab);
public:
	AdaBoostClassifier();
	virtual void trainClassifier(Data* TrainingData, const BoostingParam& boost_param, std::ostream *outStream = 0);
	virtual float computeError(Data* ValidationData, std::ostream *outStream = 0);
	~AdaBoostClassifier() {};
	void printEnsemble();
	std::vector<DecisionStump> getAllStumps();
	float evaluateFeaturePoint(const FeatureVector &v, Boosting_Normalization normalize = None, unsigned int rounds = 0);
	template<typename T> float evaluateFeaturePoint(const T* v, int dataLen, Boosting_Normalization normalize = None, unsigned int rounds = 0);
	virtual void loadClassifier(std::string filename);
	virtual void saveClassifier(std::string filename);
	virtual void performRounds(unsigned int numRounds, const BoostingParam& boost_param, Data* TrainingData = 0, std::ostream *outStream = 0, size_t roundOffset = 0);
	bool validModel() {return stumps.size() > 0;};
	void clearTrainingWeights() {weights.clear(); weights.reserve(0);}
	virtual void sortModel() { std::sort(stumps.begin(), stumps.end());}
	/*
	 * Sets the update mode
	 * 0 = as proposed by Viola and Jones
	 * 1 = as proposed by Hastie et. al
	 */
	void setUpdateMode(unsigned int mode) { updateMode = mode; };

	unsigned int getNumberOfRounds() {
		return stumps.size();
	}

private:
	DecisionStump getBestWeakLearnerWithoutIndex(size_t d);
	DecisionStump getBestWeakLearnerWithIndex(size_t d);
	void prepareIndex(std::ostream* outStream = 0);
	void computeSigmoidParams(const Data* trainData, std::ostream *outStream = 0);

	std::vector<DecisionStump> stumps;

	std::vector<std::vector<size_t> > sorted_index;

	//Data points and their weights
	Data* m_v;
	std::vector<float> weights;
	float sum_alpha;
	unsigned int updateMode;

	float subSampleRate;
	size_t numberSamples;

	//A list of all dimensions to draw from
	std::vector<size_t> fullPool;
	std::vector<size_t> sampledPool;

	// Sigmoid parameters
	double A;
	double B;
};

/*
 * Some functions to store our classiers conviently in streams
 */
std::ostream& operator<<(std::ostream& output, AdaBoostClassifier& jb);
std::istream& operator>>(std::istream& input, AdaBoostClassifier& jb);

/*
 * Inlined method for fast evaluation
 */

template<typename T> inline float AdaBoostClassifier::evaluateFeaturePoint(const T* v, int /*dataLen*/, Boosting_Normalization normalize, unsigned int rounds) {
	unsigned int activeStumps = stumps.size();
	if(rounds != 0)
		activeStumps = rounds;

	// Evaluate all features
	register float s = 0;
	for(unsigned int i = 0; i < activeStumps; i++) {
		const float &val = v[stumps[i].f];
		stumps[i].value = (val * stumps[i].p  < stumps[i].theta * stumps[i].p) ? stumps[i].alpha : 0;
		s += stumps[i].value;
	}

	switch(normalize) {
		case Ratio: {
			s /= sum_alpha;
			break;
		}

		case Sigmoid: {
			register float fApB = s * A + B;
			if (fApB >= 0)
				s = std::exp(-fApB)/(1.0f + std::exp(-fApB));
			else
				s = 1.0f /(1.0f + std::exp(fApB));
			break;
		}

		default:
			break;
	}

	return s;
}

#endif /*ADABOOST_H_*/
