#include <octave/oct.h>

extern "C" {
  // mex.cc names both mexFunction (c) and MEXFUNCTION (Fortran)
  // but the mex file only defines one of them, so define the other
  // here just to keep the linker happy, but don't ever call it.
  void F77_FUNC(mexfunction,MEXFUNCTION)() {}
  const char *mexFunctionName = "mexjointboosting";
} ;

DEFUN_DLD(mexjointboosting, args, nargout,
"\
MEXJOINTBOOSTINGwrapperforthefastc++JointBoostinglibrary\n\
\n\
1)training\n\
[setidx,param,kc]=mexjointboosting(numberOfClasses,classIdx,features,numWeakClassifiers,0);\n\
\n\
where:\n\
numberOfClassesisint>0\n\
classIdxisnx1vectorofint>0.nisthenumberoftrainingsamples\n\
featuresisnxdmatrix.nisnumberoftrainingsamplesofdimensiond\n\
numWeakClassifiersisint>0\n\
\n\
fifthparameterisomittedfornow\n\
\n\
2)classification\n\
class=mexjointboosting(vec)\n\
\n\
where:\n\
vecisdx1datavector\n\
classisnx1classpredictionvector\n\
\n\
3)resetting\n\
callingmexjointboostingwithoutparametersresetstheclassifier\n\
\n\
")
{
  octave_value_list C_mex(const octave_value_list &, const int);
  return C_mex(args, nargout);
}
