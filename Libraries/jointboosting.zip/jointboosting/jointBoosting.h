#ifndef JOINTBOOSTING_H_
#define JOINTBOOSTING_H_

/*
 * Implementation of
 * Sharing Features: efficient boosting procedures for multiclass object detection
 * by Torralba et al. in CVPR 2004
 *
 * later PAMI paper changed notation!
 */

#include <featurevector.hh>
#include <iostream>
#include <bitset>
#include <cmath>
#include <BoostingData.h>
#include <Boosting.h>

#define JB_MAXCLASSES 128

class SharingSet {
public:
	 inline SharingSet(const SharingSet& from, size_t cNew) {
     	n = from.getSet();
        n.set(cNew);
      }

      inline SharingSet(const std::bitset<JB_MAXCLASSES>& initSet) {
      	n = initSet;
      }

	  inline SharingSet() {
	  }

      inline bool isEmpty() const {
      	return n.none();
      }

      inline bool contains(size_t c) const {
      	return n.test(c);
      }

      inline const std::bitset<JB_MAXCLASSES>& getSet() const {return n;}

private:
	 std::bitset<JB_MAXCLASSES> n;
};

/*
 *  If not stated differently a always denotes \hat{a}, i.e. a = a + b
 */
struct RegressionStump {
	float theta;				// Threshold
	float a,b;					// Regression parameters, a = a + b!, b = b (notion changed in PAMI paper)
	int f;						// Feature number
	float J_wse;				// Error measure
	SharingSet S;				// Sharing subset of classes
	std::vector<float> k;		// Constants for classes not contained in the sharing set
	float value;				// Keeps the value during inference
};

inline bool operator<(const RegressionStump& rs1, const RegressionStump& rs2)  {
	return (rs1.f < rs2.f);
}

class JointBoostClassifier : public BoostingAlgorithm{
	friend std::ostream& operator<<(std::ostream& output, JointBoostClassifier& jb);
	friend std::istream& operator>>(std::istream& input, JointBoostClassifier& jb);
public:
	JointBoostClassifier() : m_v(0) {};
	~JointBoostClassifier() {};
	virtual void trainClassifier(Data* TrainingData, const BoostingParam& boost_param, std::ostream *outStream = 0);
	virtual float computeError(Data* ValidationData, std::ostream *outStream = 0);

	void printEnsembles();
	void printAllStumps();
	std::vector<float> evaluateFeaturePoint(const FeatureVector &v, Boosting_Normalization normalize = None, bool softmax = false, unsigned int rounds = 0);
	void evaluateFeaturePoint(const FeatureVector& v, std::vector<float>& rval, Boosting_Normalization normalize = None, bool softmax = false, unsigned int rounds = 0);
	template<typename T>void evaluateFeaturePoint(const T* v, int dataLen, std::vector<float>& rval, Boosting_Normalization normalize = None, bool softmax = false, unsigned int rounds = 0);
	virtual void loadClassifier(std::string filename);
	virtual void saveClassifier(std::string filename);
	virtual void performRounds(unsigned int numRounds, const BoostingParam& boost_param, Data* TrainingData = 0, std::ostream *outStream = 0, size_t roundOffset = 0);
	virtual void sortModel() {
		sort(stumps.begin(), stumps.end());

		//Rebuild correct back linkage
		for(size_t i = 0; i < ensemble.size(); ++i) {
			ensemble[i].clear();
			for(size_t j = 0; j < stumps.size(); ++j)
				if(stumps[j].S.contains(i))
					ensemble[i].push_back(j);
		}
	}

	size_t getNumberOfClasses() {
		return ensemble.size();
	}

	size_t getNumberOfRounds() {
		return stumps.size();
	}

	const std::vector<RegressionStump>& getStumps(){
	        return stumps;
	}
	const std::vector<double>& getSigmoidA(){
	        return A;
	}

	const std::vector<double>& getSigmoidB(){
	        return B;
	}
	float getMarginScaling(size_t classID);

private:

	void precomputeErrorFunctionAndK(SharingSet *lastS, bool IndexedTraining);
	void precomputeK();
	void precomputeAandBIndexed(SharingSet *lastS);
	void precomputeAandBNonIndexed(SharingSet *lastS);
	void precomputeAandB_fullScan_NonIndexed(size_t d);
	void precomputeAandB_fullScan_Indexed(size_t d);
	void precomputeAandB_boundaries_NonIndexed(size_t d);
	void precomputeAandB_boundaries_Indexed(size_t d);
	void prepareIndex(std::ostream *outStream, bool IndexedTraining, JB_Scanning scanMethod, size_t numTheta);
	RegressionStump findBestSubset(size_t d);
	RegressionStump findBestSubset_fullScan(bool indexed, size_t d);
	RegressionStump findBestSubset_boundaries(size_t d);

	RegressionStump getBestWeakLearner(const SharingSet& S, size_t d, float errorTerm, size_t lastAdded, const std::vector<float> &a_n, const std::vector<float> &b_n,const std::vector<float> &a_d, const std::vector<float> &b_d);
	RegressionStump getBestWeakLearner_fullScan(const SharingSet& S, bool indexed, size_t d, float errorTerm, size_t lastAdded, const std::vector<float> &a_n, const std::vector<float> &b_n,const std::vector<float> &a_d, const std::vector<float> &b_d);
	RegressionStump getBestWeakLearner_boundaries(const SharingSet& S, size_t d, float errorTerm, size_t lastAdded, const std::vector<float> &a_n, const std::vector<float> &b_n,const std::vector<float> &a_d, const std::vector<float> &b_d);

	void computeNormalizers();
	void computeSigmoidParams(const Data* trainData, std::ostream *outStream = 0);

	std::vector< std::vector<size_t> > ensemble;   // strong classifiers H(v,c) for each class c
	std::vector<RegressionStump> stumps;

	//Data points and their weights
	Data* m_v;
	std::vector<std::vector<float> > weights;

	//Constants to account for different number of positive and negative examples
	std::vector<float> k;				//k^c
	std::vector<float> k_n;				//\sum w_i^c z_i^z
	std::vector<float> k_d;				//\sum w_i^c
	std::vector<float> l;				//\sum_M w_i^c(z_i^c - k^c)^2

	//Thresholds for regression stumps
	std::vector<std::vector<float> > theta;
	std::vector<std::vector<size_t> > theta_index;

	std::vector<std::vector<std::vector<float> > > theta_class;
	std::vector<std::vector<std::vector<size_t> > >theta_class_index;

	std::vector<std::vector<size_t> > sorted_index;

	//values for precomputed error function
	std::vector<std::vector<std::vector<float> > > b_c;			// b_c
	std::vector<std::vector<std::vector<float> > > a_c;			//a_c + b_c
	std::vector<std::vector<std::vector<float> > > w_cplus;
	std::vector<std::vector<std::vector<float> > > w_cminus;

	//values for precomputed error function for full scan
	std::vector<std::vector<float> > b_c_full;			// b_c
	std::vector<std::vector<float> > a_c_full;			//a_c + b_c
	std::vector<std::vector<float> > w_cplus_full;
	std::vector<std::vector<float> > w_cminus_full;

	// Binary class membership
	std::vector<std::vector<float> >z;

	float subSampleRate;
	size_t numberSamples;

	//A list of all dimensions to draw from
	std::vector<size_t> fullPool;
	std::vector<size_t> sampledPool;

	float minScore;
	float scoreNorm;

	//Background class flags
	std::vector<bool> background;
	size_t numbg;

	//A vector for sorting data along one dimension
	std::vector<BoostingDataPoint> sorted_data;

	//Coefficients for sigmoid
	std::vector<double> A;
	std::vector<double> B;
};


//More efficient version for fast evaluation
inline void JointBoostClassifier::evaluateFeaturePoint(const FeatureVector& v, std::vector<float>& rval, Boosting_Normalization normalize, bool softmax, unsigned int rounds) {
	size_t activeStumps = stumps.size();
	if(rounds != 0)
		activeStumps = rounds;

	// Evaluate all features
	for(size_t i = 0; i < activeStumps; i++) {
		const float& val = v.getData(stumps[i].f);
		stumps[i].value = (val > stumps[i].theta ? stumps[i].a : stumps[i].b);
	}

	//Combine features according to sharing sets
	float sumH = 0;
	for(size_t c = 0; c < ensemble.size(); c++) {

		if(background[c]) {
			rval[c] = 0;
			continue;
		}

		register float H = 0;
		for(size_t l = 0; l < ensemble[c].size(); l++)
			if (ensemble[c][l] < activeStumps)
				H += stumps[ensemble[c][l]].value;

		switch(normalize) {
			case Ratio: {
				H = (H - minScore) * scoreNorm;
				break;
			}

			case Sigmoid: {
				register float fApB = H * A[c] + B[c];
				if (fApB >= 0)
					H = std::exp(-fApB)/(1.0f + std::exp(-fApB));
				else
					H = 1.0f /(1.0f + std::exp(fApB));
				break;
			}

			default:
				break;
		}

		if(!softmax) {
			rval[c] = H;
		} else {
			rval[c] = std::exp(H);
			sumH += rval[c];
		}
	}

	if (softmax) {
		sumH = 1.0f / sumH;
		for(unsigned int c = 0; c < ensemble.size(); c++)
			rval[c] *= sumH;
	}
}

template<typename T> inline void JointBoostClassifier::evaluateFeaturePoint(const T* v, int /*dataLen*/, std::vector<float>& rval, Boosting_Normalization normalize, bool softmax, unsigned int rounds) {
	size_t activeStumps = stumps.size();
	if(rounds != 0)
		activeStumps = rounds;

	// Evaluate all features
	for(size_t i = 0; i < activeStumps; i++) {
		const float &val = v[stumps[i].f];
		stumps[i].value = (val > stumps[i].theta ? stumps[i].a : stumps[i].b);
	}

	//Combine features according to sharing sets
	float sumH = 0;
	for(size_t c = 0; c < ensemble.size(); c++) {

		if(background[c]) {
			rval[c] = 0;
			continue;
		}

		register float H = 0;
		for(size_t l = 0; l < ensemble[c].size(); l++)
			if (ensemble[c][l] < activeStumps)
				H += stumps[ensemble[c][l]].value;

		switch(normalize) {
			case Ratio: {
				H = (H - minScore) * scoreNorm;
				break;
			}

			case Sigmoid: {
				register float fApB = H * A[c] + B[c];
				if (fApB >= 0)
					H = std::exp(-fApB)/(1.0f + std::exp(-fApB));
				else
					H = 1.0f /(1.0f + std::exp(fApB));
				break;
			}

			default:
				break;
		}

		if(!softmax) {
			rval[c] = H;
		} else {
			rval[c] = std::exp(H);
			sumH += rval[c];
		}
	}

	if (softmax) {
		sumH = 1.0f / sumH;
		for(unsigned int c = 0; c < ensemble.size(); c++)
			rval[c] *= sumH;
	}
}

/*
 * Some functions to store our classiers conviently in streams
 */
std::ostream& operator<<(std::ostream& output, JointBoostClassifier& jb);
std::istream& operator>>(std::istream& input, JointBoostClassifier& jb);

#endif /*JOINTBOOSTING_H_*/
