/*
 * Boosting.cc
 *
 *  Created on: Nov 12, 2008
 *      Author: Christian Wojek
 */

#include <Boosting.h>
#include <BoostingData.h>
#include <iostream>
#include <cmath>

void BoostingAlgorithm::trainClassifierWithXV(Data* TrainingData, const BoostingParam& boost_param, std::ostream *outStream) {
	if (TrainingData->getN() == 0) {
		std::cout << "No training data available..." << std::endl;
		return;
	}

	if (boost_param.xv_foldsUsed > boost_param.xv_n_folds) {
		std::cout << "Inconsistent number of used and overall folds..." << std::endl;
		return;
	}

	if (2 * boost_param.xv_interval > boost_param.numRounds) {
		std::cout << "2 * xv interval needs to be  < boost_param.numRounds" << std::endl;
		return;
	}

	Data allData(*TrainingData);
	allData.randomizeData();

	const std::vector<FeatureVector*>* dataP = allData.getAllSamples();
	const std::vector<float>& classWeights = allData.getClassWeights();

	//Set up the folds
	std::vector<Data> folds(boost_param.xv_n_folds, Data(TrainingData->getD(), TrainingData->getC()));
	for(size_t i = 0; i < TrainingData->getN(); ++i) {
		folds[i % boost_param.xv_n_folds].addSample( (*dataP)[i] );
	}

	//Copy the classWeights (necessary to compute the error)
	for(size_t f = 0; f < boost_param.xv_n_folds; ++f) {
		folds[f].setClassWeight(classWeights);
	}

	size_t overAllMin = boost_param.numRounds;
	for(size_t i = 0; i < boost_param.xv_foldsUsed; ++i) {

		Data trainD(TrainingData->getD(), TrainingData->getC());
		trainD.setClassWeight(classWeights);

		// Add n-1 folds
		for(size_t f = 0; f < boost_param.xv_n_folds; ++f) {
			// fold i is supposed to be the held out set
			if(i == f)
				continue;

			dataP = folds[f].getAllSamples();
			for(size_t j = 0; j < folds[f].getN(); ++j) {
				trainD.addSample( (*dataP)[j] );
			}
		}

		//Start the actual training
		BoostingParam xvbp(boost_param);
		xvbp.numRounds = boost_param.xv_interval;
		trainClassifier(&trainD, xvbp, outStream);

		//Run first xv
		float minError =  computeError(&folds[i], outStream);
		size_t minRounds = boost_param.xv_interval;

		for(size_t r = boost_param.xv_interval; r < boost_param.numRounds; r += boost_param.xv_interval) {
			performRounds(std::min(boost_param.xv_interval, boost_param.numRounds - r) , boost_param, &trainD, outStream, r);

			//Run xv
			float error = computeError(&folds[i], outStream);
			if(error < minError) {
				minError = error;
				minRounds = r + std::min(boost_param.xv_interval, boost_param.numRounds - r);
			}

			if(error > minError * (1.0 + boost_param.xv_maxIncrease))
				break;
		}

		overAllMin = std::min(minRounds, overAllMin);
	}

	BoostingParam xvp(boost_param);
	xvp.numRounds = overAllMin;
	trainClassifier(TrainingData, xvp, outStream );
}

// Platt's binary SVM Probablistic Output: an improvement from Lin et al. (copied from libSVM)
void BoostingAlgorithm::sigmoid_train(const std::vector<double>& dec_values, const std::vector<double>& labels, double& A, double& B)
{
	double prior1=0, prior0 = 0;
	int i;

	int l = dec_values.size();

	for (i=0;i<l;i++)
		if (labels[i] > 0) prior1+=1;
		else prior0+=1;

	int max_iter=100; 	// Maximal number of iterations
	double min_step=1e-10;	// Minimal step taken in line search
	double sigma=1e-3;	// For numerically strict PD of Hessian
	double eps=1e-5;
	double hiTarget=(prior1+1.0)/(prior1+2.0);
	double loTarget=1/(prior0+2.0);
	double *t= new double[l];
	double fApB,p,q,h11,h22,h21,g1,g2,det,dA,dB,gd,stepsize;
	double newA,newB,newf,d1,d2;
	int iter;

	// Initial Point and Initial Fun Value
	A=0.0; B=std::log((prior0+1.0)/(prior1+1.0));
	double fval = 0.0;

	for (i=0;i<l;i++)
	{
		if (labels[i]>0) t[i]=hiTarget;
		else t[i]=loTarget;
		fApB = dec_values[i]*A+B;
		if (fApB>=0)
			fval += t[i]*fApB + std::log(1+std::exp(-fApB));
		else
			fval += (t[i] - 1)*fApB +std::log(1+std::exp(fApB));
	}
	for (iter=0;iter<max_iter;iter++)
	{
		// Update Gradient and Hessian (use H' = H + sigma I)
		h11=sigma; // numerically ensures strict PD
		h22=sigma;
		h21=0.0;g1=0.0;g2=0.0;
		for (i=0;i<l;i++)
		{
			fApB = dec_values[i]*A+B;
			if (fApB >= 0)
			{
				p=std::exp(-fApB)/(1.0+std::exp(-fApB));
				q=1.0/(1.0+std::exp(-fApB));
			}
			else
			{
				p=1.0/(1.0+std::exp(fApB));
				q=std::exp(fApB)/(1.0+std::exp(fApB));
			}
			d2=p*q;
			h11+=dec_values[i]*dec_values[i]*d2;
			h22+=d2;
			h21+=dec_values[i]*d2;
			d1=t[i]-p;
			g1+=dec_values[i]*d1;
			g2+=d1;
		}

		// Stopping Criteria
		if (std::abs(g1)<eps && std::abs(g2)<eps)
			break;

		// Finding Newton direction: -inv(H') * g
		det=h11*h22-h21*h21;
		dA=-(h22*g1 - h21 * g2) / det;
		dB=-(-h21*g1+ h11 * g2) / det;
		gd=g1*dA+g2*dB;


		stepsize = 1; 		// Line Search
		while (stepsize >= min_step)
		{
			newA = A + stepsize * dA;
			newB = B + stepsize * dB;

			// New function value
			newf = 0.0;
			for (i=0;i<l;i++)
			{
				fApB = dec_values[i]*newA+newB;
				if (fApB >= 0)
					newf += t[i]*fApB + std::log(1+std::exp(-fApB));
				else
					newf += (t[i] - 1)*fApB +std::log(1+std::exp(fApB));
			}
			// Check sufficient decrease
			if (newf<fval+0.0001*stepsize*gd)
			{
				A=newA;B=newB;fval=newf;
				break;
			}
			else
				stepsize = stepsize / 2.0;
		}

		if (stepsize < min_step)
		{
			std::cout << "Line search fails in two-class probability estimates\n";
			break;
		}
	}

	if (iter>=max_iter)
		std::cout << "Reaching maximal iterations in two-class probability estimates\n";
	delete[](t);
}

