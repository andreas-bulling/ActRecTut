#include <iostream>
#include <fstream>
#include <jointBoosting.h>
#include <time.h>
#include <sys/types.h>
#include "mex.h"
#include "matrix.h"
#define _WIN32
using namespace std;
JointBoostClassifier *jbc=0;
static void jboost(int num_classes,int num_datavec, int dim_datavec, int num_rounds, float minErr,double* cp, double * dp, mxArray *plhs[]){
    cout << "num_classes: "<<num_classes<<" num_datavec: "<<num_datavec<<" dim_datavec: "<<dim_datavec<<endl;
    vector<FeatureVector> data;
    Data TrainingData(dim_datavec,num_classes);
    for(uint i=0; i<num_datavec;i++){
        FeatureVector f(dim_datavec);
        //if(i==0)
        //  cout << (int)(cp[i])<<" ";
        for(uint j=0;j<dim_datavec;j++){
          //if(i==0)
          //  cout << (dp[i+j*num_datavec])<< " ";
            f.setValue(j,dp[i+j*num_datavec]);
        }
        //if(i==0)
        //  cout<<endl;;
        f.setTargetClass((int)(cp[i]));
        data.push_back(f);
    }
    cout << "converting done"<<endl;

    TrainingData.addSampleVector(data);
    TrainingData.setBackgroundClass(0);

    jbc=new JointBoostClassifier();
    //jbc->trainClassifier(&TrainingData, num_rounds, minErr, &std::cout);

	BoostingParam bp;
	bp.numRounds = num_rounds;
	bp.subSampleRate = 1.0;
	bp.randomSeed = 42;
	bp.IndexedTraining = true;

	bp.xv_n_folds = 5;
	bp.xv_foldsUsed = 1;
	bp.xv_interval = 10;
	bp.xv_maxIncrease = 0.02;

	bp.jb_weight_initialization = Pos50NegClassEqual; // JB_Weighting {Pos50NegClassEqual, Pos50NegAllEqual, AllTheSame};
	bp.jb_num_theta = 2000; //theta, ignored when jb_full_theta_scan == true
	bp.jb_refine_withFullScan = true;
	bp.jb_theta_scan = Linear; // JB_Scanning {Full, Quantiles, Linear, Boundaries};

    jbc->trainClassifier(&TrainingData, bp, &std::cout);
	//jbc->trainClassifierWithXV(&TrainingData, bp, &std::cout);
    jbc->printAllStumps();
    cout <<"training done"<<endl;

    /*       for(int y = 1; y < 200; y+=5) {
                    for(int x = 0; x < 200; x+=5) {
                            FeatureVector t(2);
                            t.setValue(0, x);
                            t.setValue(1, y);
                            vector<float> testRes = jbc.evaluateFeaturePoint(t);

                            int maxIndex = 0;
                            float maxVal = testRes[0];
                            for(unsigned int i = 0; i < testRes.size(); i++) {
                                    if (testRes[i] > maxVal) {
                                            maxIndex = i;
                                            maxVal = testRes[i];
                                    }
                            }
                            cout << maxIndex;
                    }
                    cout << endl;
            }
    */
    mxArray* setidx = mxCreateNumericMatrix(num_rounds,1,mxUINT64_CLASS,mxREAL); //return  set membership as (max 64) bit encoding
    mxArray* param = mxCreateNumericMatrix(num_rounds,4,mxDOUBLE_CLASS,mxREAL);  //a,b,f,theta
    mxArray* kc = mxCreateNumericMatrix(num_rounds, num_classes, mxDOUBLE_CLASS, mxREAL);

    mxArray* ASigmoid  = mxCreateNumericMatrix(1, num_classes, mxDOUBLE_CLASS, mxREAL);
    mxArray* BSigmoid = mxCreateNumericMatrix(1, num_classes, mxDOUBLE_CLASS, mxREAL);
    
    u_int64_t* setidxp = (u_int64_t *)mxGetData(setidx);
    double* paramp = mxGetPr(param);
    double* kcp = mxGetPr(kc);
    double* ASigmoidp = mxGetPr(ASigmoid);
    double* BSigmoidp = mxGetPr(BSigmoid);
    const std::vector<double>& A = jbc->getSigmoidA();
    const std::vector<double>& B = jbc->getSigmoidB();

    const std::vector<RegressionStump>& stumps = jbc->getStumps();
    for(unsigned int i = 0; i < stumps.size(); i++) {
        *(setidxp) = stumps[i].S.getSet().to_ulong();
        cerr << (int) (*setidxp)<<" ";
        setidxp++;
        *(paramp)              = (double)stumps[i].a ;
        *(paramp+  num_rounds) = (double)stumps[i].b ;
        *(paramp+2*num_rounds) = (double)stumps[i].f ;
        *(paramp+3*num_rounds) = (double)stumps[i].theta;
        //cerr <<(double)jbc->stumps[i].a<<" "<<(double)jbc->stumps[i].b<<" "<<(double)jbc->stumps[i].f<<" "<<(double)jbc->stumps[i].theta<<endl;
        paramp++;
        for(unsigned j = 0; j < stumps[i].k.size(); j++) {
            *(kcp+j*num_rounds) = (double)stumps[i].k[j];
        }
        kcp++;
    }
    for(unsigned int i = 0; i < num_classes;i++) {
     	*(ASigmoidp) = (double)A[i];
     	*(BSigmoidp) = (double)B[i];
	ASigmoidp++;
	BSigmoidp++;
     }
    //jbc.printAllStumps();
    plhs[0] = setidx;
    plhs[1] = param;
    plhs[2] = kc;
    plhs[3] = ASigmoid;
    plhs[4] = BSigmoid;
   
}
int gnum_classes;
int gnum_datavec;
int gdim_datavec;
int gnum_rounds;
extern "C" {
    void mexFunction(
        int          nlhs,
        mxArray      *plhs[],
        int          nrhs,
        const mxArray *prhs[]
    )
    {


        if (nrhs == 5) {
            //mexErrMsgTxt("Four arguments required: num class, class vec [nx1], feature vec matrix [nxm], num boost rounds, minError (disabled by now)\n");


            if (mxGetN(prhs[0]) != 1 || mxGetM(prhs[0]) != 1 || mxIsComplex(prhs[0])|| mxIsClass(prhs[0],"sparse") || mxIsChar(prhs[0]))
                mexErrMsgTxt("first arg must be scalar\n");
            int num_classes = (int)(*mxGetPr(prhs[0]));
            if (mxGetN(prhs[1]) != 1 || mxIsComplex(prhs[1])|| mxIsClass(prhs[1],"sparse") || mxIsChar(prhs[1]))
                mexErrMsgTxt("second arg must be nx1 vector\n");
            int num_datavec=mxGetM(prhs[1]);

            if (mxGetM(prhs[2]) != num_datavec || mxIsComplex(prhs[2])|| mxIsClass(prhs[2],"sparse") || mxIsChar(prhs[2]))
                mexErrMsgTxt("third arg must be nxm matrix\n");
            int dim_datavec=mxGetN(prhs[2]);
            if (mxGetN(prhs[3]) != 1  || mxGetM(prhs[3]) != 1 || mxIsComplex(prhs[3])|| mxIsClass(prhs[3],"sparse") || mxIsChar(prhs[3]))
                mexErrMsgTxt("fourth arg must be scalar\n");
            if (mxGetN(prhs[4]) != 1  || mxGetM(prhs[4]) != 1 || mxIsComplex(prhs[4])|| mxIsClass(prhs[4],"sparse") || mxIsChar(prhs[4]))
                mexErrMsgTxt("fifth arg must be scalar\n");

            int num_rounds = (int)(*mxGetPr(prhs[3]));
            double minErr = *mxGetPr(prhs[4]);

            cout << "num_classes: "<<num_classes<<" num_datavec: "<<num_datavec<<" dim_datavec: "<<dim_datavec<< " minErr: "<<minErr<<endl;
            double* cp=mxGetPr(prhs[1]);
            double* dp=mxGetPr(prhs[2]);
            gnum_classes=num_classes;
            gnum_datavec=num_datavec;
            gdim_datavec=dim_datavec;
            gnum_rounds=num_rounds;
            jboost(num_classes, num_datavec, dim_datavec, num_rounds, (float)minErr,cp, dp, plhs);
        }
        else if (nrhs == 1){
            int dim_vec=mxGetM(prhs[0]);

            if(dim_vec == gdim_datavec && jbc != 0){
                double* dp=mxGetPr(prhs[0]);
                FeatureVector t(dim_vec);
                for(int d=0;d<dim_vec; d++){
                    t.setValue(d,*dp);
                    dp++;
                }
                vector<float> testRes = jbc->evaluateFeaturePoint(t);
                mxArray* res = mxCreateNumericMatrix(testRes.size(),1,mxDOUBLE_CLASS,mxREAL);
                dp=mxGetPr(res);
                for(int i=0;i<testRes.size();i++){
                    dp[i]=testRes.at(i);
                }
                plhs[0]=res;
            }
        }
        else if (nrhs == 0){
            if(jbc != 0)
                delete jbc;
        } else { cerr<< "dont know what todo"<<endl;}

        //plhs[0] = mxCreateDoubleMatrix(num_training_sets,1, mxREAL);
        //one_result = mxGetPr(plhs[0]);
        //predictone(mxGetPr(prhs[0]));
        //*(mxGetPr(plhs[0])) = res;
        //mexPrintf("PASS:) ped: %f\n",res);


        return;
    }
}
