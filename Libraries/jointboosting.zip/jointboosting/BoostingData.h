#ifndef BOOSTINGDATA_H_
#define BOOSTINGDATA_H_

#include <featurevector.hh>
#include <algorithm>
#include <vector>

struct BoostingDataPoint{
	float m_value;
	int m_index;

	BoostingDataPoint(float value, int index) : m_value(value), m_index(index) {};
};

inline bool operator<( const BoostingDataPoint& i1, const BoostingDataPoint& i2) {
	return (i1.m_value < i2.m_value);
};

class Data{
public:
	Data(size_t D, size_t C);
	~Data();

	/*
	 *  Be aware that addresses might change if further elements are added to &s!!!!
	 * So only construct dataSet and then run Boosting training immediately
	 *
	 */
	void addSample(FeatureVector* s);
	void addSampleVector(std::vector<FeatureVector> &s);

	void setClassWeight(size_t c, float weight) {
		if(c > m_C -1)
			return;

		classWeights[c] = weight;
	}

	void setClassWeight(const std::vector<float>& weights) {
		if(weights.size() != classWeights.size())
			return;

		classWeights = weights;
	}

	const std::vector<FeatureVector*>* getAllSamples() const {
		return &m_samples;
	}

	const std::vector<FeatureVector*>* getSamplesOfClass(int c) const {
		return &(m_samples_of_class[c]);
	}

	inline void randomizeData() {
		std::random_shuffle(m_samples.begin(), m_samples.end());

		for(size_t i = 0; i < m_samples_of_class.size(); ++i)
			std::random_shuffle(m_samples_of_class[i].begin(), m_samples_of_class[i].end());
	}

	inline float getClassWeight(size_t c) const  {return classWeights[c];}
	inline const std::vector<float>& getClassWeights() const {return classWeights;}
	inline size_t getC() const {return m_C;};
	inline size_t getN() const {return m_N;};
	inline size_t getD() const {return m_D;};

	void clear();

	void resetBackgroundClasses() {
		background = std::vector<bool>(m_C, false);
	}

	void setBackgroundClass(size_t classID) {
		background[classID] = true;
	}

	void setBackgroundClass(const std::vector<size_t>& classIDs) {
		for(size_t i = 0; i < classIDs.size(); ++i) {
			if(classIDs[i] < m_C)
				background[classIDs[i]] = true;
		}
	}

	bool isBackground(size_t classID) {
		return background[classID];
	}

protected:
	size_t m_D;				//Overall number of features D
	size_t m_N;				//Overall number of training samples N
	size_t m_C;				//Overall number of classes C
	std::vector<FeatureVector*> m_samples;
	std::vector< std::vector<FeatureVector*> > m_samples_of_class;
	std::vector<float> classWeights;

	std::vector<bool> background;
};


#endif /*BOOSTINGDATA_H_*/
