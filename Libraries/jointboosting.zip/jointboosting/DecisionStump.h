/*
 * DecisionStump.h
 *
 *  Created on: Nov 9, 2008
 *      Author: wojek
 */

#ifndef DECISIONSTUMP_H_
#define DECISIONSTUMP_H_

struct DecisionStump {
	int f;						// Feature number
	float p;					// Sign for < vs. > in the stump node
	float theta;				// Threshold
	float alpha;				// Weak learner's weight

	float J_wse;				// Error measure
	float value;				// Keeps the value during inference
};

inline bool operator<(const DecisionStump& ds1, const DecisionStump& ds2)  {
	return (ds1.f < ds2.f);
}

#endif /* DECISIONSTUMP_H_ */
