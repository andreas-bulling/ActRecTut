function [pclass,val]=jbclassify(nclass, set_idx, param, kc, datavec)
% check what vec dims meet threshod constrain
vidx=(datavec(param(:,3)+1,1) > param(:,4));
% 
val=vidx .* param(:,1) + (ones(size(set_idx,1),1) - vidx).*param(:,2);

pclass=zeros(1,nclass);

for c=1:nclass
    ensidx=(bitand(set_idx,2^(c-1))>0); %all weak classifiers judging a class subset that contains c
    %kcidx=ones(size(set_idx,1),1) - ensidx; % the opposite selection, no longer needed
    %fk=find(kcidx);
    tmp=ensidx.*val; % + kcidx.*kc(:,c); Not so in christian's and antonio's code
    %tmp=ensidx.*val;
    %tmp=ensidx.*val+kc(fk(size(fk,1)),c); % chritians code is fixed ...
    pclass(1,c)=sum(tmp,1);
end
