KPMtools is a directory of miscellaneous matlab functions written by
Kevin Patrick Murphy and various other people (see individual file headers).

